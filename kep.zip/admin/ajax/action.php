<?php
        define('UPLOAD_DIR', 'upload/');
        include"kon.php";
   
        $img        = $_POST['image'];
        $nik       = $_POST['nik']; 
        $langli       = $_POST['langli']; 
        $longli       = $_POST['longli']; 
        $img        = str_replace('data:image/jpeg;base64,', '', $img);
        $img        = str_replace(' ', '+', $img);
    
        $data       = base64_decode($img);
        $file       = uniqid() . '.png';
        
		$tanggal=date("Y-m-d");
		$jam=date("H");
		$menit=date("i");
		$cek=mysqli_query($con,"select * from tb_karyawan where nik='$_POST[nik]'");
		$det=mysqli_fetch_array($cek);
		$masuk=8;
		$menitmasuk=00;
		$pulang=17;
		$menitpulang=00;
		
		if($jam<=$masuk && $menit<$menitmasuk){
			$cek=mysqli_query($con,"select * from tb_absen where nik='$_POST[nik]' and tanggal=curdate()");
			if(mysqli_num_rows($cek)>0){
				echo "
					<script>
						alert('Karyawan ini sudah absen masuk');
						document.location='Absen';
					</script>	
				";
			}else{
				mysqli_query($con,"insert into tb_absen values('null','$_POST[nik]',curdate(),now(),'MASUK','H','$file','$_POST[langli]','$_POST[longli]')");
				file_put_contents(UPLOAD_DIR.$file, $data);
				echo "
					<script>
						alert('Absen masuk berhasil');
						document.location='Absen';
					</script>	
				";
			}
		}elseif($jam>=$masuk && $jam<$pulang){
			$cek=mysqli_query($con,"select * from tb_absen where nik='$_POST[nik]' and tanggal=curdate()");
			if(mysqli_num_rows($cek)>0){
				echo "
					<script>
						alert('Karyawan ini sudah absen masuk');
						document.location='Absen';
					</script>	
				";
			}else{
				mysqli_query($con,"insert into tb_absen values('null','$_POST[nik]',curdate(),now(),'MASUK','H','$file','$_POST[langli]','$_POST[longli]')");
				file_put_contents(UPLOAD_DIR.$file, $data);
				echo "
					<script>
						alert('Anda sudah telat');
						document.location='Absen';
					</script>	
				";
			}
		}elseif($jam>=$pulang){
			$lembur=$jam-$pulang;
			$cek=mysqli_query($con,"select * from tb_absen where nik='$_POST[nik]' and tanggal=curdate()");
			if(mysqli_num_rows($cek)>0){
				$da=mysqli_fetch_array($cek);
				if($da['pulang']=='00:00:00'){
					mysqli_query($con,"insert into tb_absen values('null','$_POST[nik]',curdate(),now(),'PULANG','H','$file','$_POST[langli]','$_POST[longli]')");
					echo "
					<script>
						alert('Absen pulang berhasil');
						document.location='Absen';
					</script>	
				";
				}else{
					echo "
					<script>
						alert('Absen pulang sudah dilakukan');
						document.location='Absen';
					</script>	
				";
				}
			}
		}else{
			echo "
				<script>
					alert('Absen Pulang Dimulai Pukul 16:00 !');
				</script>
			";
			}
    ?>