<?php
setlocale(LC_TIME, 'id_ID.UTF8');
 
$awal_cuti = date("d-m-Y",strtotime($_POST['dari_tgl']));
$akhir_cuti =date("d-m-Y",strtotime($_POST['sampai_tgl']));;
 
// tanggalnya diubah formatnya ke Y-m-d 
$awal_cuti = date_create_from_format('d-m-Y', $awal_cuti);
$awal_cuti = date_format($awal_cuti, 'Y-m-d');
$awal_cuti = strtotime($awal_cuti);
 
$akhir_cuti = date_create_from_format('d-m-Y', $akhir_cuti);
$akhir_cuti = date_format($akhir_cuti, 'Y-m-d');
$akhir_cuti = strtotime($akhir_cuti);
 
$haricuti = array();
$sabtuminggu = array();
 
for ($i=$awal_cuti; $i <= $akhir_cuti; $i += (60 * 60 * 24)) {
    if (date('w', $i) !== '0') {
        $haricuti[] = $i;
    } else {
        $sabtuminggu[] = $i;
    }
 
}
echo $jumlah_cuti = count($haricuti);
?>