<?php
	include"kon.php";
	$nik=$_POST['nik'];
	$data=mysqli_fetch_array(mysqli_query($con,"select * from tb_karyawan where nik=$nik"));
	$json['nik']			= ( ! empty($data['nik'])) ? $data['nik'] : "<small><i>Tidak ada</i></small>";
	$json['nama']			= ( ! empty($data['nama'])) ? preg_replace("/\r\n|\r|\n/",'<br />', $data['nama']) : "<small><i>Tidak ada</i></small>";
	$json['jabatan']		= ( ! empty($data['jabatan'])) ? $data['jabatan'] : "<small><i>Tidak ada</i></small>";
	$json['no_hp']			= ( ! empty($data['no_hp'])) ? $data['no_hp'] : "<small><i>Tidak ada</i></small>";
	$json['email']			= ( ! empty($data['email'])) ? $data['email'] : "<small><i>Tidak ada</i></small>";
	$json['foto']			= ( ! empty("<img src='assets/images/foto/".$data['foto']."' width='150px'>")) ? "<img src='assets/images/foto/".$data['foto']."' width='150px'>" : "<small><i>Tidak ada</i></small>";
	echo json_encode($json);
?>