<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Absen extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_absen');
		$this->load->model('M_karyawan');
		if(!isset($_SESSION['log'])){header("location:".site_url("Login"));}
	}

	public function index($jenis=null,$id=null)
	{
		$data['url']='Absen/tambah';
		$data['aksi']="tambah";

		if($jenis=="ubah"){
			$data['cd']=$this->M_absen->cari_absen("*", "where id_absen='$id'")->row_array(0);
			$data['url']=site_url('Absen/ubah/'.$id);
			$data['aksi']="ubah";
		}
		$data['menu'] = "Absen";
		$data['tampil']=$this->M_absen->cari_absen("*,tb_absen.foto as fot","where tb_absen.nik='$_SESSION[nik]'");
		$data['nik']=$this->M_karyawan->cari_karyawan("*","where tb_karyawan.nik='$_SESSION[nik]'");
		$this->load->view('include/header',$data);
		$this->load->view('absen/absen',$data);
		$this->load->view('include/footer');
	}
	
	public function lihat()
	{
		$data['menu'] = "Data Absen";
		$data['tampil']=$this->M_absen->cari_absen("*,tb_absen.foto as fot"," ");
		$this->load->view('include/header',$data);
		$this->load->view('absen/lihat',$data);
		$this->load->view('include/footer');
	}
	
}
