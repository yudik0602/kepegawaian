<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cetak extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_cuti');
		$this->load->model('M_karyawan');
		$this->load->model('M_resign');
		$this->load->model('M_dp');
		$this->load->model('M_phk');
		$this->load->model('M_rp');
		$this->load->model('M_penugasan');
		$this->load->model('M_absen');
		$this->load->model('M_rekrutment');
		if(!isset($_SESSION['log'])){header("location:".site_url("Login"));}
	}
	
	public function cuti($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Cuti";
		if(isset($_GET['nik'])){
			$data['tampil']=$this->M_cuti->cari_cuti("*","where tb_cuti.tgl_simpan>='$_GET[awal]' and tb_cuti.tgl_simpan<='$_GET[akhir]' and tb_cuti.nik='$_GET[nik]' order by id_cuti desc");
		}
		else{
			$data['tampil']=$this->M_cuti->cari_cuti("*","where tb_cuti.tgl_simpan>='$_GET[awal]' and tb_cuti.tgl_simpan<='$_GET[akhir]' order by id_cuti desc");
		}
		$this->load->view('cetak/cuti',$data);
	}
	public function pertahun($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Cuti";
		if(isset($_GET['tahun'])){
			$data['tampil']=$this->M_cuti->cari_cuti("*","where year(tb_cuti.tgl_simpan)='$_GET[tahun]' group by tb_cuti.nik asc");
		}
		$this->load->view('cetak/pertahun',$data);
	}
	public function resign($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Resign";
		if(isset($_GET['awal'])){
			$data['tampil']=$this->M_resign->cari_resign("*","where tb_resign.tgl_simpan>='$_GET[awal]' and tb_resign.tgl_simpan<='$_GET[akhir]' order by id_resign desc");
		}
		$this->load->view('cetak/resign',$data);
	}
	public function dp($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Promosi & Demosi";
		if(isset($_GET['awal'])){
			$data['tampil']=$this->M_dp->cari_dp("*","where tb_dp.tgl_simpan>='$_GET[awal]' and tb_dp.tgl_simpan<='$_GET[akhir]' order by id_dp desc");
		}
		$this->load->view('cetak/dp',$data);
	}
	public function phk($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data PHK";
		if(isset($_GET['awal'])){
			$data['tampil']=$this->M_phk->cari_phk("*","where tb_phk.tgl_simpan>='$_GET[awal]' and tb_phk.tgl_simpan<='$_GET[akhir]' order by id_phk desc");
		}
		$this->load->view('cetak/phk',$data);
	}
	public function rp()
	{
		$data['menu'] = "Laporan Data Rewad/Punisment";
		if(isset($_GET['awal'])){
			$data['tampil']=$this->M_rp->cari_rp("*,tb_rp.status_rp as stt","where tb_rp.tgl_simpan>='$_GET[awal]' and tb_rp.tgl_simpan<='$_GET[akhir]' order by id_rp desc");
		}
		$this->load->view('cetak/rp',$data);
	}
	public function penugasan($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Penugasan";
		if(isset($_GET['awal'])){
			$data['tampil']=$this->M_penugasan->cari_penugasan("*","where tb_penugasan.tgl_penugasan>='$_GET[awal]' and tb_penugasan.tgl_penugasan<='$_GET[akhir]' order by id_penugasan desc");
		}
		$this->load->view('cetak/penugasan',$data);
	}
	public function absen($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Absen";
		if(isset($_GET['bulan'])){
			$data['tampil']=$this->M_absen->cari_absen("*,count(*) as total","where month(tb_absen.tanggal)='$_GET[bulan]' and year(tb_absen.tanggal)='$_GET[tahun]' and tb_absen.ket='MASUK' group by tb_absen.nik asc");
		}
		$this->load->view('cetak/absen',$data);
	}
	public function gaji($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Gaji";
		if(isset($_GET['bulan'])){
			$data['tampil']=$this->db->query("select *,count(*) as total from tb_karyawan inner join tb_absen on tb_absen.nik=tb_karyawan.nik where month(tb_absen.tanggal)='$_GET[bulan]' and year(tb_absen.tanggal)='$_GET[tahun]' and tb_absen.ket='MASUK' group by tb_absen.nik asc");
		}
		$this->load->view('cetak/gaji',$data);
	}
	
	public function karyawan($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Karyawan";
		$data['tampil']=$this->M_karyawan->cari_karyawan("*","order by nik asc");
		$this->load->view('cetak/karyawan',$data);
	}
	public function rekrutment($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Calon Karyawan";
		if(isset($_GET['awal'])){
			$data['tampil']=$this->M_rekrutment->cari_rekrutment("*","where tanggal_input>='$_GET[awal]' and tanggal_input<='$_GET[akhir]'order by id_rekrutment desc");
		}
		$this->load->view('cetak/rekrutment',$data);
	}
}
