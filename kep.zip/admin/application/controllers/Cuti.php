<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cuti extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_cuti');
		$this->load->model('M_karyawan');
		if(!isset($_SESSION['log'])){header("location:".site_url("Login"));}
	}
	
	public function index($jenis=null,$id=null)
	{
		$data['url']='Cuti/tambah';
		$data['aksi']="tambah";

		if(isset($_GET['nik'])){
			$data['jatah']=$this->M_cuti->cari_cuti("*"," where tb_cuti.nik='$_GET[nik]'")->row_array(0);
			$data['kar']=$this->M_karyawan->cari_karyawan("*"," where tb_karyawan.nik='$_GET[nik]'")->row_array(0);
		}
		if($jenis=='ubah'){
			$data['cd']=$this->M_cuti->cari_cuti("*,tb_cuti.status_cuti as stt"," where tb_cuti.id_cuti='$id'")->row_array(0);
			$data['kar']=$this->M_cuti->cari_cuti("*"," where tb_cuti.id_cuti='$id'")->row_array(0);
			$data['url']=site_url('Cuti/ubah/'.$id);
			$data['aksi']="ubah";
		}
				
		$data['controller'] = $this->router->fetch_class();
		$data['menu'] = "Cuti";
		$data['tampil']=$this->M_cuti->cari_cuti("*","where tb_cuti.nik='$_SESSION[nik]'");
		$data['nik']=$this->M_karyawan->cari_karyawan("*","where status_kerja='Aktif' and nik='$_SESSION[nik]'");
		$this->load->view('include/header',$data);
		$this->load->view('cuti/cuti',$data);
		$this->load->view('include/footer');
	}
	
	public function lihat($jenis=null,$id=null)
	{
		$data['menu'] = "Data Cuti";
		$data['tampil']=$this->M_cuti->cari_cuti("*","order by id_cuti desc");
		$this->load->view('include/header',$data);
		$this->load->view('cuti/lihat_cuti');
		$this->load->view('include/footer');
	}
	
	public function validasi($jenis=null,$id=null)
	{
		$data['menu'] = "Validasi Data Cuti";
		$data['tampil']=$this->M_cuti->cari_cuti("*","where status_cuti='Diinput' order by id_cuti desc");
		$this->load->view('include/header',$data);
		$this->load->view('cuti/validasi');
		$this->load->view('include/footer');
	}
	
	public function tambah(){
		$tanggal=date("Y-m-d");
		if($_POST['dari_tgl']<$tanggal){
			echo "<script>alert('Maaf tidak boleh pilih tanggal kemarin !');document.location='".site_url('Cuti')."'</script>";
			exit;
		}
		if($_POST['sampai_tgl']<$tanggal){
			echo "<script>alert('Maaf tidak boleh pilih tanggal kemarin !');document.location='".site_url('Cuti')."'</script>";
			exit;
		}
		if($_POST['kategori_cuti']=="Umum"){
			if($_POST['lama_cuti']>12){
				echo "<script>alert('Maaf maksimal cuti 12 hari !');document.location='".site_url('Cuti')."'</script>";
				exit;
			}
			if($_POST['lama_cuti']>$_POST['sisa']){
				echo "<script>alert('Maaf lama cuti melebihi sisa cuti !');document.location='".site_url('Cuti')."'</script>";
				exit;
			}
		}
		
		$this->M_cuti->nik=$_POST['nik'];
		$this->M_cuti->kategori_cuti=$_POST['kategori_cuti'];
		$this->M_cuti->dari_tgl=$_POST['dari_tgl'];
		$this->M_cuti->sampai_tgl=$_POST['sampai_tgl'];
		$this->M_cuti->lama_cuti=$_POST['lama_cuti'];
		$this->M_cuti->keterangan=$_POST['keterangan'];
		$this->M_cuti->status_cuti='Diinput';
		$this->M_cuti->tgl_simpan=date('Y-m-d');
		$this->M_cuti->ket_val="";
		$this->M_cuti->tambah_cuti();
		echo "<script>alert('Cuti berhasil disimpan');document.location='".site_url('Cuti')."'</script>";
	}
	public function ubah($id){
		$this->M_cuti->nik=$_POST['nik'];
		$this->M_cuti->kategori_cuti=$_POST['kategori_cuti'];
		$this->M_cuti->dari_tgl=$_POST['dari_tgl'];
		$this->M_cuti->sampai_tgl=$_POST['sampai_tgl'];
		$this->M_cuti->lama_cuti=$_POST['lama_cuti'];
		$this->M_cuti->keterangan=$_POST['keterangan'];
		$this->M_cuti->status_cuti='Diinput';
		$this->M_cuti->tgl_simpan=date('Y-m-d');
		$this->M_cuti->ubah_cuti($id);
		echo "<script>alert('Cuti berhasil diubah');document.location='".site_url('Cuti')."'</script>";
	}
	
	public function terima($id){
		$this->db->query("update tb_cuti set status_cuti='Divalidasi' where id_cuti='$id'");
		
		echo "<script>alert('Cuti berhasil divalidasi');document.location='".site_url('Cuti')."'</script>";
	}
	public function tolak($id){
		$this->db->query("update tb_cuti set status_cuti='Ditolak' where id_cuti='$id'");
		echo "<script>alert('Cuti ditolak');document.location='".site_url('Cuti')."'</script>";
	}
	
	public function hapus($id){
		$this->M_cuti->hapus_cuti($id);
		echo "<script>alert('Data berhasil dihapus !');document.location='".site_url('Cuti')."'</script>";
	}
}
