<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dp extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_dp');
		$this->load->model('M_karyawan');
		if(!isset($_SESSION['log'])){header("location:".site_url("Login"));}
	}

	public function index($jenis=null,$id=null)
	{
		$data['url']='Dp/tambah';
		$data['aksi']="tambah";

		if($jenis=='ubah'){
			$data['cd']=$this->M_dp->cari_dp("*"," where tb_dp.id_dp='$id'")->row_array(0);
			$data['kar']=$this->M_dp->cari_dp("*"," where tb_dp.id_dp='$id'")->row_array(0);
			$data['url']=site_url('Dp/ubah/'.$id);
			$data['aksi']="ubah";
		}
				
		$data['menu'] = "Dempsi & Promosi";
		$data['tampil']=$this->M_dp->cari_dp("*","");
		$data['nik']=$this->M_karyawan->cari_karyawan("*","where tb_karyawan.status_kerja='Aktif'");
		$this->load->view('include/header',$data);
		$this->load->view('dp/dp',$data);
		$this->load->view('include/footer');
	}
	public function lihat()
	{
		$data['menu'] = "Dempsi & Promosi";
		$data['tampil']=$this->M_dp->cari_dp("*","where tb_karyawan.nik='$_SESSION[nik]'");
		$this->load->view('include/header',$data);
		$this->load->view('dp/lihat',$data);
		$this->load->view('include/footer');
	}
		
	public function tambah(){
		$this->M_dp->nik=$_POST['nik'];
		$this->M_dp->dari_jabatan=$_POST['dari_jabatan'];
		$this->M_dp->ke_jabatan=$_POST['ke_jabatan'];
		$this->M_dp->alasan=$_POST['alasan'];
		$this->M_dp->status_dp=$_POST['status_dp'];
		$this->M_dp->tgl_dp=$_POST['tgl_dp'];
		$this->M_dp->tgl_simpan=date('Y-m-d');
		$this->M_dp->tambah_dp();
		$this->db->query("update tb_karyawan set jabatan='$_POST[ke_jabatan]' where nik='$_POST[nik]'");
		echo "<script>alert('Data berhasil disimpan');document.location='".site_url('Dp')."'</script>";
	}
	public function ubah($id){
		$this->M_dp->dari_jabatan=$_POST['dari_jabatan'];
		$this->M_dp->ke_jabatan=$_POST['ke_jabatan'];
		$this->M_dp->alasan=$_POST['alasan'];
		$this->M_dp->status_dp=$_POST['status_dp'];
		$this->M_dp->tgl_dp=$_POST['tgl_dp'];
		$this->M_dp->tgl_simpan=date('Y-m-d');
		$this->M_dp->ubah_dp($id);
		echo "<script>alert('Data berhasil disimpan');document.location='".site_url('Dp')."'</script>";
	}
	
	public function hapus($id){
		$this->M_dp->hapus_dp($id);
		echo "<script>alert('Data berhasil dihapus');document.location='".site_url('Dp')."'</script>";
	}
}
