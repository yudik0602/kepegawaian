<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gaji extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_gaji');
		if(!isset($_SESSION['log'])){header("location:".site_url("Login"));}
	}
	
	public function index($jenis=null,$id=null)
	{
		$data['url']='Gaji/tambah';
		$data['aksi']="tambah";
		
		$data['menu'] = "Data Gaji Karyawan";
		if(isset($_POST['cari'])){
			$data['tampil']=$this->db->query("select *,count(*) as total from tb_karyawan inner join tb_absen on tb_absen.nik=tb_karyawan.nik where month(tb_absen.tanggal)='$_POST[bulan]' and year(tb_absen.tanggal)='$_POST[tahun]' and tb_absen.ket='MASUK' group by tb_absen.nik asc");
		}
		$this->load->view('include/header',$data);
		$this->load->view('gaji/gaji');
		$this->load->view('include/footer');
	}
	public function tambah(){
		$cek=$this->db->query("select count(*) as cek from tb_gaji where tb_gaji.bln_gaji='$_POST[bln]' and tb_gaji.thn_gaji='$_POST[tahun]'")->row_array(0);
		if($cek['cek']>0){
			$ambil=$this->db->query("select *,count(*) as total from tb_karyawan inner join tb_absen on tb_absen.nik=tb_karyawan.nik where month(tb_absen.tanggal)='$_POST[bln]' and year(tb_absen.tanggal)='$_POST[tahun]' and tb_absen.ket='MASUK' group by tb_absen.nik asc");
				foreach($ambil->result_array() as $res){
					$update=$this->db->query("update tb_gaji set ttl_kehadiran='".$_POST['ttl_'.$res['nik']]."',uang_makan='".$_POST['m_'.$res['nik']]."',uang_transport='".$_POST['t_'.$res['nik']]."',bpjs_kesehatan='".$_POST['kes_'.$res['nik']]."',bpjs_ketenagakerjaan='".$_POST['ten_'.$res['nik']]."',gapok='".$_POST['gp_'.$res['nik']]."',total='".$_POST['total_'.$res['nik']]."' where bln_gaji='$_POST[bulan]' and thn_gaji='$_POST[tahun]' and nik='".$_POST['n_'.$res['nik']]."'");
				}
		}else{
			$ambil=$this->db->query("select *,count(*) as total from tb_karyawan inner join tb_absen on tb_absen.nik=tb_karyawan.nik where month(tb_absen.tanggal)='$_POST[bln]' and year(tb_absen.tanggal)='$_POST[tahun]' and tb_absen.ket='MASUK' group by tb_absen.nik asc");
			foreach($ambil->result_array() as $res){
				$this->M_gaji->nik=$_POST['n_'.$res['nik']];
				$this->M_gaji->bln_gaji=$_POST['bln'];
				$this->M_gaji->thn_gaji=$_POST['tahun'];
				$this->M_gaji->ttl_kehadiran=$_POST['ttl_'.$res['nik']];
				$this->M_gaji->uang_makan=$_POST['m_'.$res['nik']];
				$this->M_gaji->uang_transport=$_POST['t_'.$res['nik']];
				$this->M_gaji->bpjs_kesehatan=$_POST['kes_'.$res['nik']];
				$this->M_gaji->bpjs_ketenagakerjaan=$_POST['ten_'.$res['nik']];
				$this->M_gaji->gapok=$_POST['gp_'.$res['nik']];
				$this->M_gaji->total=$_POST['total_'.$res['nik']];
				$this->M_gaji->tgl_simpan=date('Y-m-d');
				$this->M_gaji->tambah_gaji();
			}
		}
		
		echo "<script>alert('Gaji berhasil disimpan');document.location='".site_url('Gaji')."'</script>";
		
	}
	public function slip($jenis=null,$id=null)
	{
		$data['menu'] = "Slip Gaji";
		if(isset($_POST['cari'])){
			$data['tampil']=$this->db->query("select * from tb_gaji where bln_gaji='$_POST[bulan]' and thn_gaji='$_POST[tahun]' and nik='$_SESSION[nik]'")->row_array(0);
			$tampil=$this->db->query("select *, count(*) as cek from tb_gaji where bln_gaji='$_POST[bulan]' and thn_gaji='$_POST[tahun]' and nik='$_SESSION[nik]'")->row_array(0);
			if($tampil['cek']!=1){
				echo "<script>alert('Slip Gaji belum tersedia !');document.location='".site_url('Gaji/slip')."'</script>";
			}
		}
		$this->load->view('include/header',$data);
		$this->load->view('gaji/slip');
		$this->load->view('include/footer');
	}
}
