<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Karyawan extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_karyawan');
		if(!isset($_SESSION['log'])){header("location:".site_url("login"));}
	}

	public function index($jenis=null,$id=null)
	{
		$data['url']='Karyawan/tambah';
		$data['aksi']="tambah";
		
		$data['menu']="Karyawan";
		$data['tampil']=$this->M_karyawan->cari_karyawan("*","");
		
		if($jenis=="ubah"){
			$data['cd']=$this->M_karyawan->cari_karyawan("*", "where nik='$id'")->row_array(0);
			$data['url']=site_url('karyawan/ubah/'.$id);
			$data['aksi']="ubah";
		}
		
		$this->load->view('include/header',$data);
		$this->load->view('karyawan/karyawan',$data);
		$this->load->view('include/footer');
	}
	public function tambah(){
		$this->M_karyawan->nik=$_POST['nik'];
		$this->M_karyawan->no_ktp=$_POST['no_ktp'];
		$this->M_karyawan->nama=$_POST['nama'];
		$this->M_karyawan->no_hp=$_POST['no_hp'];
		$this->M_karyawan->alamat=$_POST['alamat'];
		$this->M_karyawan->email=$_POST['email'];
		$this->M_karyawan->status=$_POST['status'];
		$this->M_karyawan->tempat_lahir=$_POST['tempat_lahir'];
		$this->M_karyawan->tgl_lahir=$_POST['tgl_lahir'];
		$this->M_karyawan->jenis_kelamin=$_POST['jenis_kelamin'];
		$this->M_karyawan->agama=$_POST['agama'];
		$this->M_karyawan->gol_darah=$_POST['gol_darah'];
		$this->M_karyawan->pendidikan=$_POST['pendidikan'];
		$this->M_karyawan->jabatan=$_POST['jabatan'];
		
		$config['upload_path']='./assets/images/foto';
		$config['overwrite'] = true;
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']=5120;
		$config['file_name']= $_FILES['foto']['name'];
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		if($this->upload->do_upload('foto')) {
			$this->M_karyawan->foto=$_FILES['foto']['name'];
		}
		
		$config['upload_path']='./assets/images/lam_ijazah';
		$config['overwrite'] = true;
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']=5120;
		$config['file_name']= $_FILES['lam_ijazah']['name'];
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		if($this->upload->do_upload('lam_ijazah')) {
			$this->M_karyawan->lam_ijazah=$_FILES['lam_ijazah']['name'];
		}
		
		$config['upload_path']='./assets/images/lam_kk';
		$config['overwrite'] = true;
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']=5120;
		$config['file_name']= $_FILES['lam_kk']['name'];
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		if($this->upload->do_upload('lam_kk')) {
			$this->M_karyawan->lam_kk=$_FILES['lam_kk']['name'];
		} 
		
		$config['upload_path']='./assets/images/lam_ktp';
		$config['overwrite'] = true;
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']=5120;
		$config['file_name']= $_FILES['lam_ktp']['name'];
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		if($this->upload->do_upload('lam_ktp')) {
			$this->M_karyawan->lam_ktp=$_FILES['lam_ktp']['name'];
		} 
		$this->M_karyawan->gaji_pokok=$_POST['gaji_pokok'];
		$this->M_karyawan->uang_makan=$_POST['uang_makan'];
		$this->M_karyawan->uang_transport=$_POST['uang_transport'];
		$this->M_karyawan->bpjs_kesehatan=$_POST['bpjs_kesehatan'];
		$this->M_karyawan->bpjs_ketenagakerjaan=$_POST['bpjs_ketenagakerjaan'];
		$this->M_karyawan->tgl_masuk=$_POST['tgl_masuk'];
		$this->M_karyawan->tgl_simpan=date('Y-m-d');
		$this->M_karyawan->status_kerja='Aktif';
		$this->M_karyawan->tambah_karyawan();
		echo "<script>alert('Karyawan berhasil disimpan');document.location='".site_url('Karyawan')."'</script>";
	}
	public function ubah($id){
		$this->M_karyawan->no_ktp=$_POST['no_ktp'];
		$this->M_karyawan->nama=$_POST['nama'];
		$this->M_karyawan->no_hp=$_POST['no_hp'];
		$this->M_karyawan->alamat=$_POST['alamat'];
		$this->M_karyawan->email=$_POST['email'];
		$this->M_karyawan->status=$_POST['status'];
		$this->M_karyawan->tempat_lahir=$_POST['tempat_lahir'];
		$this->M_karyawan->tgl_lahir=$_POST['tgl_lahir'];
		$this->M_karyawan->jenis_kelamin=$_POST['jenis_kelamin'];
		$this->M_karyawan->agama=$_POST['agama'];
		$this->M_karyawan->gol_darah=$_POST['gol_darah'];
		$this->M_karyawan->pendidikan=$_POST['pendidikan'];
		$this->M_karyawan->jabatan=$_POST['jabatan'];
		
		$config['upload_path']='./assets/images/foto';
		$config['overwrite'] = true;
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']=5120;
		$config['file_name']= $_FILES['foto']['name'];
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		if($this->upload->do_upload('foto')) {
			$this->M_karyawan->foto=$_FILES['foto']['name'];
		}
		
		$config['upload_path']='./assets/images/lam_ijazah';
		$config['overwrite'] = true;
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']=5120;
		$config['file_name']= $_FILES['lam_ijazah']['name'];
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		if($this->upload->do_upload('lam_ijazah')) {
			$this->M_karyawan->lam_ijazah=$_FILES['lam_ijazah']['name'];
		}
		
		$config['upload_path']='./assets/images/lam_kk';
		$config['overwrite'] = true;
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']=5120;
		$config['file_name']= $_FILES['lam_kk']['name'];
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		if($this->upload->do_upload('lam_kk')) {
			$this->M_karyawan->lam_kk=$_FILES['lam_kk']['name'];
		} 
		
		$config['upload_path']='./assets/images/lam_ktp';
		$config['overwrite'] = true;
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']=5120;
		$config['file_name']= $_FILES['lam_ktp']['name'];
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		if($this->upload->do_upload('lam_ktp')) {
			$this->M_karyawan->lam_ktp=$_FILES['lam_ktp']['name'];
		} 
		
		$this->M_karyawan->gaji_pokok=$_POST['gaji_pokok'];
		$this->M_karyawan->uang_makan=$_POST['uang_makan'];
		$this->M_karyawan->uang_transport=$_POST['uang_transport'];
		$this->M_karyawan->bpjs_kesehatan=$_POST['bpjs_kesehatan'];
		$this->M_karyawan->bpjs_ketenagakerjaan=$_POST['bpjs_ketenagakerjaan'];
		$this->M_karyawan->tgl_masuk=$_POST['tgl_masuk'];
		$this->M_karyawan->tgl_simpan=date('Y-m-d');
		$this->M_karyawan->ubah_karyawan($id);
		echo "<script>alert('Karyawan berhasil diubah');document.location='".site_url('Karyawan')."'</script>";
	}
	public function info($id=null)
	{
		$data['menu'] = "Info Karyawan";
		$data['tampil']=$this->M_karyawan->cari_karyawan("*"," where nik='$id'")->row_array(0);
		$this->load->view('include/header',$data);
		$this->load->view('karyawan/info',$data);
		$this->load->view('include/footer');
	}
	public function hapus($id){
		$this->M_karyawan->hapus_karyawan($id);
		echo "<script>alert('Karyawan berhasil dihapus');document.location='".site_url('Karyawan')."'</script>";
	}
}
