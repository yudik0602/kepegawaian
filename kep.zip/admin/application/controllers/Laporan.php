<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_cuti');
		$this->load->model('M_karyawan');
		$this->load->model('M_resign');
		$this->load->model('M_dp');
		$this->load->model('M_phk');
		$this->load->model('M_rp');
		$this->load->model('M_penugasan');
		$this->load->model('M_absen');
		$this->load->model('M_rekrutment');
		if(!isset($_SESSION['log'])){header("location:".site_url("Login"));}
	}
	
	public function index($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Cuti";
		if(isset($_POST['cari'])){
			if($_POST['nik']=='all'){
				$data['tampil']=$this->M_cuti->cari_cuti("*","where tb_cuti.tgl_simpan>='$_POST[dari_tgl]' and tb_cuti.tgl_simpan<='$_POST[sampai_tgl]' order by id_cuti desc");
			}else{
				$data['tampil']=$this->M_cuti->cari_cuti("*","where tb_cuti.tgl_simpan>='$_POST[dari_tgl]' and tb_cuti.tgl_simpan<='$_POST[sampai_tgl]' and tb_cuti.nik='$_POST[nik]' order by id_cuti desc");
			}
		}
		$data['nik']=$this->M_karyawan->cari_karyawan("*","where tb_karyawan.status_kerja='Aktif'");
		$this->load->view('include/header',$data);
		$this->load->view('laporan/cuti');
		$this->load->view('include/footer');
	}
	public function cuti($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Cuti";
		if(isset($_POST['cari'])){
			$data['tampil']=$this->M_cuti->cari_cuti(" * ","where year(tb_cuti.tgl_simpan)>='$_POST[tahun]' group by tb_cuti.nik asc");
		}
		$this->load->view('include/header',$data);
		$this->load->view('laporan/pengajuan_cuti');
		$this->load->view('include/footer');
	}
	public function resign($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Resign";
		if(isset($_POST['cari'])){
			$data['tampil']=$this->M_resign->cari_resign("*","where tb_resign.tgl_simpan>='$_POST[dari_tgl]' and tb_resign.tgl_simpan<='$_POST[sampai_tgl]' order by id_resign desc");
		}
		$this->load->view('include/header',$data);
		$this->load->view('laporan/resign');
		$this->load->view('include/footer');
	}
	public function dp($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Promosi & Demosi";
		if(isset($_POST['cari'])){
			$data['tampil']=$this->M_dp->cari_dp("*","where tb_dp.tgl_simpan>='$_POST[dari_tgl]' and tb_dp.tgl_simpan<='$_POST[sampai_tgl]' order by id_dp desc");
		}
		$this->load->view('include/header',$data);
		$this->load->view('laporan/dp');
		$this->load->view('include/footer');
	}
	public function phk($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data PHK";
		if(isset($_POST['cari'])){
			$data['tampil']=$this->M_phk->cari_phk("*","where tb_phk.tgl_simpan>='$_POST[dari_tgl]' and tb_phk.tgl_simpan<='$_POST[sampai_tgl]' order by id_phk desc");
		}
		$this->load->view('include/header',$data);
		$this->load->view('laporan/phk');
		$this->load->view('include/footer');
	}
	public function rp($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Reward/Punishment";
		if(isset($_POST['cari'])){
			$data['tampil']=$this->M_rp->cari_rp("*,tb_rp.status_rp as stt","where tb_rp.tgl_simpan>='$_POST[dari_tgl]' and tb_rp.tgl_simpan<='$_POST[sampai_tgl]' order by id_rp desc");
		}
		$this->load->view('include/header',$data);
		$this->load->view('laporan/rp');
		$this->load->view('include/footer');
	}
	public function penugasan($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Penugasan";
		if(isset($_POST['cari'])){
			$data['tampil']=$this->M_penugasan->cari_penugasan("*","where tb_penugasan.tgl_penugasan>='$_POST[dari_tgl]' and tb_penugasan.tgl_penugasan<='$_POST[sampai_tgl]' order by id_penugasan desc");
		}
		$this->load->view('include/header',$data);
		$this->load->view('laporan/penugasan');
		$this->load->view('include/footer');
	}
	public function absen($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Absen";
		if(isset($_POST['cari'])){
			$data['tampil']=$this->M_absen->cari_absen("*,count(*) as total","where month(tb_absen.tanggal)='$_POST[bulan]' and year(tb_absen.tanggal)='$_POST[tahun]' and tb_absen.ket='MASUK' group by tb_absen.nik asc");
		}
		$this->load->view('include/header',$data);
		$this->load->view('laporan/absen');
		$this->load->view('include/footer');
	}
	public function gaji($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Gaji Karyawan";
		if(isset($_POST['cari'])){
			$data['tampil']=$this->db->query("select *,count(*) as total from tb_karyawan inner join tb_absen on tb_absen.nik=tb_karyawan.nik where month(tb_absen.tanggal)='$_POST[bulan]' and year(tb_absen.tanggal)='$_POST[tahun]' and tb_absen.ket='MASUK' group by tb_absen.nik asc");
		}
		$this->load->view('include/header',$data);
		$this->load->view('laporan/gaji');
		$this->load->view('include/footer');
	}
	public function karyawan($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Karyawan";
		$data['tampil']=$this->M_karyawan->cari_karyawan("*","order by nik asc");
		$this->load->view('include/header',$data);
		$this->load->view('laporan/karyawan');
		$this->load->view('include/footer');
	}
	public function rekrutment($jenis=null,$id=null)
	{
		$data['menu'] = "Laporan Data Rekrutment";
		if(isset($_POST['cari'])){
			$data['tampil']=$this->M_rekrutment->cari_rekrutment("*","where tanggal_input>='$_POST[dari_tgl]' and tanggal_input<='$_POST[sampai_tgl]'order by id_rekrutment desc");
		}
		$this->load->view('include/header',$data);
		$this->load->view('laporan/rekrutment');
		$this->load->view('include/footer');
	}
}
