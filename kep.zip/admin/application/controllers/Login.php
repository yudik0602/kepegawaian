<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_pengguna');
		if($this->session->userdata('status')=="Supervisor Operasional"){header("location:".base_url("welcome"));}
		if($this->session->userdata('status')=="Staff Penjualan"){header("location:".base_url("welcome"));}
		if($this->session->userdata('status')=="Staff Pembelian"){header("location:".base_url("welcome"));}
		if($this->session->userdata('status')=="Manager Operasional"){header("location:".base_url("welcome"));}
	}
	
	public function index()
	{
		$data['controller'] = $this->router->fetch_class();
		$data['menu']="Login";
		$this->load->view('login/login');
	}
	public function login()
	{
		$cari_pengguna=$this->M_pengguna->cari_pengguna("*","inner join tb_karyawan on tb_karyawan.nik=tb_pengguna.nik where tb_pengguna.nik='$_POST[nik]' and tb_karyawan.status_kerja='Aktif'");
		if($cari_pengguna->num_rows()==1){
			$res=$cari_pengguna->row_array(0);
			if(password_verify($_POST['password'],$res['password'])){
				$this->session->set_userdata('log',$res['id_pengguna']);
				$this->session->set_userdata('nik',$res['nik']);
				$this->session->set_userdata('nama_lengkap',$res['nama']);
				$this->session->set_userdata('status',$res['akses']);
				$this->session->set_userdata('foto',$res['foto']);
				echo "<script>alert('Login Berhasil');document.location='".site_url('welcome')."'</script>";
			}else{
				echo "<script>alert('Password salah silahkan coba lagi !');document.location='".site_url('login')."'</script>";
			}
		}
		else{
			echo "<script>alert('Maaf penggunaname anda salah !');document.location='".site_url('login')."'</script>";
		}
	}
	public function logout(){
		$this->session->sess_destroy();
		header("location:".site_url("./"));
	}
}
