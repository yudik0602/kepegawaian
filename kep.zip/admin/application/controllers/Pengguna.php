<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengguna extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_pengguna');
		$this->load->model('M_karyawan');
		if(!isset($_SESSION['log'])){header("location:".site_url("login"));}
	}

	public function index($jenis=null,$id=null)
	{
		$data['url']='Pengguna/tambah';
		$data['aksi']="tambah";
		
		$data['menu']="Pengguna";
		$data['tampil']=$this->M_pengguna->cari_pengguna("*","");
		
		if($jenis=="ubah"){
			$data['cd']=$this->M_pengguna->cari_pengguna("*", "where nik='$id'")->row_array(0);
			$data['url']=site_url('pengguna/ubah/'.$id);
			$data['aksi']="ubah";
			$data['karyawan']=$this->M_karyawan->cari_karyawan("*","inner join tb_pengguna on tb_pengguna.nik=tb_karyawan.nik where tb_pengguna.nik='$id' limit 1");
		}else{
			$data['karyawan']=$this->M_karyawan->cari_karyawan("*","where nik not in (select nik from tb_pengguna)");
		}
		
		$this->load->view('include/header',$data);
		$this->load->view('pengguna/pengguna',$data);
		$this->load->view('include/footer');
	}
	public function tambah(){
		$cek=$this->db->query("select count(*) as cek from tb_pengguna where nik='".$_POST['nik']."'")->row_array(0);
		if($cek['cek']>0) {
			echo "<script>alert('Maaf nik sudah terdaftar');document.location='".site_url('Pengguna')."'</script>";
			exit;
		}
		$this->M_pengguna->nik=$_POST['nik'];
		$this->M_pengguna->akses=$_POST['akses'];
		$options = [
			'cost' => 10,
		];
		$this->M_pengguna->password=password_hash($_POST['password'],PASSWORD_DEFAULT,$options);
		$this->M_pengguna->tgl_simpan=date('Y-m-d');
		$this->M_pengguna->tambah_pengguna();
		echo "<script>alert('Pengguna berhasil disimpan');document.location='".site_url('Pengguna')."'</script>";
	}
	public function ubah($id){
		$this->M_pengguna->nik=$_POST['nik'];
		$this->M_pengguna->akses=$_POST['akses'];
		
		$this->M_pengguna->tgl_simpan=date('Y-m-d');
		$this->M_pengguna->ubah_pengguna($id);
		echo "<script>alert('Pengguna berhasil diubah');document.location='".site_url('Pengguna')."'</script>";
	}
	public function hapus($id){
		$this->M_pengguna->hapus_pengguna($id);
		echo "<script>alert('Pengguna berhasil dihapus');document.location='".site_url('Pengguna')."'</script>";
	}
}
