<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penugasan extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_penugasan');
		$this->load->model('M_karyawan');
		if(!isset($_SESSION['log'])){header("location:".site_url("Login"));}
	}

	public function index($jenis=null,$id=null)
	{
		$data['url']='Penugasan/tambah';
		$data['aksi']="tambah";

		if($jenis=='ubah'){
			$data['cd']=$this->M_penugasan->cari_penugasan("*"," where tb_penugasan.id_penugasan='$id'")->row_array(0);
			$data['kar']=$this->M_penugasan->cari_penugasan("*"," where tb_penugasan.id_penugasan='$id'")->row_array(0);
			$data['url']=site_url('Penugasan/ubah/'.$id);
			$data['aksi']="ubah";
		}
				
		$data['menu'] = "Penugasan";
		$data['tampil']=$this->M_penugasan->cari_penugasan("*","");
		$data['nik']=$this->M_karyawan->cari_karyawan("*","where tb_karyawan.status_kerja='Aktif'");
		$this->load->view('include/header',$data);
		$this->load->view('penugasan/penugasan',$data);
		$this->load->view('include/footer');
	}
	public function lihat()
	{				
		$data['menu'] = "Lihat Penugasan";
		$data['tampil']=$this->M_penugasan->cari_penugasan("*","where tb_karyawan.nik='$_SESSION[nik]'");
		$this->load->view('include/header',$data);
		$this->load->view('penugasan/lihat',$data);
		$this->load->view('include/footer');
	}
		
	public function tambah(){
		$this->M_penugasan->nik=$_POST['nik'];
		$this->M_penugasan->dari_tgl=$_POST['dari_tgl'];
		$this->M_penugasan->sampai_tgl=$_POST['sampai_tgl'];
		$this->M_penugasan->keterangan=$_POST['keterangan'];
		$this->M_penugasan->tgl_penugasan=date('Y-m-d');
		$this->M_penugasan->status_penugasan="Diinput";
		$this->M_penugasan->tambah_penugasan();
		echo "<script>alert('Penugasan berhasil disimpan');document.location='".site_url('Penugasan')."'</script>";
	}
	public function ubah($id){
		$this->M_penugasan->dari_tgl=$_POST['dari_tgl'];
		$this->M_penugasan->sampai_tgl=$_POST['sampai_tgl'];
		$this->M_penugasan->keterangan=$_POST['keterangan'];
		$this->M_penugasan->status_penugasan="Diinput";
		$this->M_penugasan->ubah_penugasan($id);
		echo "<script>alert('Penugasan berhasil diubah');document.location='".site_url('Penugasan')."'</script>";
	}
	
	public function hapus($id){
		$this->M_penugasan->hapus_penugasan($id);
		echo "<script>alert('Penugasan berhasil dihapus');document.location='".site_url('Penugasan')."'</script>";
	}
}
