<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Phk extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_phk');
		$this->load->model('M_karyawan');
		if(!isset($_SESSION['log'])){header("location:".site_url("Login"));}
	}

	public function index($jenis=null,$id=null)
	{
		$data['url']='Phk/tambah';
		$data['aksi']="tambah";

		if($jenis=='ubah'){
			$data['cd']=$this->M_phk->cari_phk("*"," where tb_phk.id_phk='$id'")->row_array(0);
			$data['kar']=$this->M_phk->cari_phk("*"," where tb_phk.id_phk='$id'")->row_array(0);
			$data['url']=site_url('Phk/ubah/'.$id);
			$data['aksi']="ubah";
		}
				
		$data['menu'] = "Phk";
		$data['tampil']=$this->M_phk->cari_phk("*","");
		$data['nik']=$this->M_karyawan->cari_karyawan("*","where tb_karyawan.status_kerja='Aktif'");
		$this->load->view('include/header',$data);
		$this->load->view('phk/phk',$data);
		$this->load->view('include/footer');
	}
		
	public function tambah(){
		$this->M_phk->nik=$_POST['nik'];
		$this->M_phk->keterangan_phk=$_POST['keterangan_phk'];
		
		$config['upload_path']='./assets/images/lam_phk';
		$config['overwrite'] = true;
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']=5120;
		$config['file_name']= $_FILES['lampiran']['name'];
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		if($this->upload->do_upload('lampiran')) {
			$this->M_phk->lampiran=$_FILES['lampiran']['name'];
		} 
		
		$this->M_phk->status_phk="Diinput";
		$this->M_phk->tgl_phk=$_POST['tgl_phk'];
		$this->M_phk->tgl_simpan=date('Y-m-d');
		$this->M_phk->tambah_phk();
		echo "<script>alert('Phk berhasil disimpan');document.location='".site_url('Phk')."'</script>";
	}
	public function ubah($id){
		$this->M_phk->keterangan_phk=$_POST['keterangan_phk'];
		
		$config['upload_path']='./assets/images/lam_phk';
		$config['overwrite'] = true;
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']=5120;
		$config['file_name']= $_FILES['lampiran']['name'];
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		if($this->upload->do_upload('lampiran')) {
			$this->M_phk->lampiran=$_FILES['lampiran']['name'];
		} 
		
		$this->M_phk->tgl_phk=$_POST['tgl_phk'];
		$this->M_phk->status_phk="Diinput";
		$this->M_phk->tgl_simpan=date('Y-m-d');
		$this->M_phk->ubah_phk($id);
		echo "<script>alert('Phk berhasil disimpan');document.location='".site_url('Phk')."'</script>";
	}
	
	public function hapus($id){
		$this->M_phk->hapus_phk($id);
		echo "<script>alert('Phk berhasil dihapus');document.location='".site_url('Phk')."'</script>";
	}
}
