<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rekrutment extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_rekrutment');
		if(!isset($_SESSION['log'])){header("location:".site_url("login"));}
	}

	public function index($jenis=null,$id=null)
	{
		$data['url']='Rekrutment/tambah';
		$data['aksi']="tambah";
		
		$data['menu']="Rekrutment";
		$data['tampil']=$this->M_rekrutment->cari_rekrutment("*","");
		
		$this->load->view('include/header',$data);
		$this->load->view('rekrutment/lihat',$data);
		$this->load->view('include/footer');
	}
	public function terima($id){
		$this->db->query("update tb_rekrutment set status_lamaran='Diterima' where id_rekrutment='$id'");
		
		echo "<script>alert('Pelamar diterima !');document.location='".site_url('Rekrutment')."'</script>";
	}
	public function tolak($id){
		$this->db->query("update tb_rekrutment set status_lamaran='Ditolak' where id_rekrutment='$id'");
		echo "<script>alert('Pelamar ditolak');document.location='".site_url('Rekrutment')."'</script>";
	}
}
