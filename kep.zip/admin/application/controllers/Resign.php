<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Resign extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_resign');
		$this->load->model('M_karyawan');
		if(!isset($_SESSION['log'])){header("location:".site_url("Login"));}
	}

	public function index($jenis=null,$id=null)
	{
		$data['url']='Resign/tambah';
		$data['aksi']="tambah";

		if(isset($_GET['nik'])){
			$data['jatah']=$this->M_resign->cari_resign("*"," where tb_resign.nik='$_GET[nik]'")->row_array(0);
			$data['kar']=$this->M_karyawan->cari_karyawan("*"," where tb_karyawan.nik='$_GET[nik]'")->row_array(0);
		}
		if($jenis=='ubah'){
			$data['cd']=$this->M_resign->cari_resign("*"," where tb_resign.id_resign='$id'")->row_array(0);
			$data['kar']=$this->M_resign->cari_resign("*"," where tb_resign.id_resign='$id'")->row_array(0);
			$data['url']=site_url('Resign/ubah/'.$id);
			$data['aksi']="ubah";
		}
				
		$data['controller'] = $this->router->fetch_class();
		$data['menu'] = "Resign";
		$data['tampil']=$this->M_resign->cari_resign("*","where tb_resign.nik='$_SESSION[nik]'");
		$data['nik']=$this->M_karyawan->cari_karyawan("*","where status_kerja='Aktif' and nik='$_SESSION[nik]'");
		$data['karya']=$this->M_karyawan->cari_karyawan("*","where status_kerja='Aktif' and nik='$_SESSION[nik]'")->row_array(0);
		$this->load->view('include/header',$data);
		$this->load->view('resign/resign',$data);
		$this->load->view('include/footer');
	}
	public function lihat()
	{		
		$data['menu'] = "Lihat Resign";
		$data['tampil']=$this->M_resign->cari_resign("*","");
		$data['nik']=$this->M_karyawan->cari_karyawan("*","where nik!='$_SESSION[nik]' and jabatan!='DIREKTUR'");
		$this->load->view('include/header',$data);
		$this->load->view('resign/lihat_resign',$data);
		$this->load->view('include/footer');
	}
	
	public function tambah(){
		$this->M_resign->nik=$_POST['nik'];
		$this->M_resign->alasan_resign=$_POST['alasan_resign'];
		$config['upload_path']='./assets/images/lam_resign';
		$config['overwrite'] = true;
		$config['max_size']=5120;
		$config['file_name']= $_FILES['lampiran']['name'];
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		if($this->upload->do_upload('lampiran')) {
			$this->M_resign->lampiran=$_FILES['lampiran']['name'];
		} 
		$this->M_resign->status_resign="Diinput";
		$this->M_resign->tgl_simpan=date('Y-m-d');
		$this->M_resign->tgl_resign=$_POST['tgl_resign'];
		$this->M_resign->tambah_resign();
		echo "<script>alert('Resign berhasil disimpan');document.location='".site_url('Resign')."'</script>";
	}
	public function ubah($id){
		$this->M_resign->alasan_resign=$_POST['alasan_resign'];
		$config['upload_path']='./assets/images/lam_resign';
		$config['overwrite'] = true;
		$config['max_size']=5120;
		$config['file_name']= $_FILES['lampiran']['name'];
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		if($this->upload->do_upload('lampiran')) {
			$this->M_resign->lampiran=$_FILES['lampiran']['name'];
		} 
		$this->M_resign->status_resign="Diinput";
		$this->M_resign->tgl_simpan=date('Y-m-d');
		$this->M_resign->tgl_resign=$_POST['tgl_resign'];
		$this->M_resign->ubah_resign($id);
		echo "<script>alert('Resign berhasil diubah');document.location='".site_url('Resign')."'</script>";
	}
	public function validasi($jenis=null,$id=null)
	{
		$data['menu'] = "Validasi Data Resign";
		$data['tampil']=$this->M_resign->cari_resign("*","where status_resign='Diinput' order by id_resign desc");
		$this->load->view('include/header',$data);
		$this->load->view('resign/validasi');
		$this->load->view('include/footer');
	}
	public function acc($id){
		$this->db->query("update tb_resign set status_resign='Divalidasi' where id_resign='$id'");
		$ambil=$this->db->query("select * from tb_resign where id_resign='$id'")->row_array(0);
		$this->db->query("update tb_karyawan set status_kerja='Tidak Aktif' where nik='$ambil[nik]'");
		echo "<script>alert('resign berhasil divalidasi');document.location='".site_url('Resign')."'</script>";
	}
	public function tolak($id){
		$this->db->query("update tb_resign set status_resign='Ditolak' where id_resign='$id'");
		echo "<script>alert('resign ditolak');document.location='".site_url('Resign')."'</script>";
	}
	public function hapus($id){
		$this->M_resign->hapus_resign($id);
		echo "<script>alert('Resign berhasil dihapus');document.location='".site_url('Resign')."'</script>";
	}
}
