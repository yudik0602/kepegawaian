<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rp extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_rp');
		$this->load->model('M_karyawan');
		if(!isset($_SESSION['log'])){header("location:".site_url("Login"));}
	}

	public function index($jenis=null,$id=null)
	{
		$data['url']='Rp/tambah';
		$data['aksi']="tambah";

		if($jenis=='ubah'){
			$data['cd']=$this->M_rp->cari_rp("*"," where tb_rp.id_rp='$id'")->row_array(0);
			$data['kar']=$this->M_rp->cari_rp("*"," where tb_rp.id_rp='$id'")->row_array(0);
			$data['url']=site_url('Rp/ubah/'.$id);
			$data['aksi']="ubah";
		}
				
		$data['menu'] = "Rewad & Punishment";
		$data['tampil']=$this->M_rp->cari_rp("*","");
		$data['nik']=$this->M_karyawan->cari_karyawan("*","where tb_karyawan.status_kerja='Aktif'");
		$this->load->view('include/header',$data);
		$this->load->view('rp/rp',$data);
		$this->load->view('include/footer');
	}
	public function lihat()
	{				
		$data['menu'] = "Rewad & Punishment";
		$data['tampil']=$this->M_rp->cari_rp("*","where tb_karyawan.nik='$_SESSION[nik]'");
		$this->load->view('include/header',$data);
		$this->load->view('rp/lihat',$data);
		$this->load->view('include/footer');
	}
		
	public function tambah(){
		$this->M_rp->nik=$_POST['nik'];
		$this->M_rp->keterangan=$_POST['keterangan'];
		
		$config['upload_path']='./assets/images/lam_rp';
		$config['overwrite'] = true;
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']=5120;
		$config['file_name']= $_FILES['lampiran']['name'];
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		if($this->upload->do_upload('lampiran')) {
			$this->M_rp->lampiran=$_FILES['lampiran']['name'];
		} 
		
		$this->M_rp->status_rp=$_POST['status_rp'];
		$this->M_rp->tgl_rp=$_POST['tgl_rp'];
		$this->M_rp->tgl_simpan=date('Y-m-d');
		$this->M_rp->tambah_rp();
		echo "<script>alert('Rp berhasil disimpan');document.location='".site_url('Rp')."'</script>";
	}
	public function ubah($id){
		$this->M_rp->keterangan=$_POST['keterangan'];
		
		$config['upload_path']='./assets/images/lam_rp';
		$config['overwrite'] = true;
		$config['allowed_types'] = 'gif|jpg|png';
		$config['max_size']=5120;
		$config['file_name']= $_FILES['lampiran']['name'];
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		if($this->upload->do_upload('lampiran')) {
			$this->M_rp->lampiran=$_FILES['lampiran']['name'];
		} 
		
		$this->M_rp->status_rp=$_POST['status_rp'];
		$this->M_rp->tgl_rp=$_POST['tgl_rp'];
		$this->M_rp->tgl_simpan=date('Y-m-d');
		$this->M_rp->ubah_rp($id);
		echo "<script>alert('Rp berhasil disimpan');document.location='".site_url('Rp')."'</script>";
	}
	
	public function hapus($id){
		$this->M_rp->hapus_rp($id);
		echo "<script>alert('Rp berhasil dihapus');document.location='".site_url('Rp')."'</script>";
	}
}
