<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ubahpass extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_pengguna');
		if(!isset($_SESSION['log'])){header("location:".site_url("Login"));}
	}

	public function index()
	{
		$data['menu'] = "Ubah Password";
		$data['url']='Ubahpass/ubah';
		$data['aksi']="tambah";
		
		$this->load->view('include/header',$data);
		$this->load->view('pengguna/ubah_pass');
		$this->load->view('include/footer');
	}
	public function ubah(){
		$cari_pengguna=$this->db->query("select * from tb_pengguna where nik='$_SESSION[nik]'");
		if($cari_pengguna->num_rows()==1){
			$res=$cari_pengguna->row_array(0);
			if(password_verify($_POST['pass_lama'],$res['password'])){
				if($_POST['pass_baru']!=$_POST['kon_pass']){
					echo "<script>alert('Maaf password baru tidak sama dengan konfirmasi password!');document.location='".site_url('Ubahpass')."'</script>";
					exit;
				}else{
					$options = [
						'cost' => 10,
					];
					$this->M_pengguna->password=password_hash($_POST['pass_baru'],PASSWORD_DEFAULT,$options);
					$this->M_pengguna->ubah_pass($_SESSION['nik']);
					echo "<script>alert('Password berhasil diubah');document.location='".site_url('Ubahpass')."'</script>";
				}
			}else{
				echo "<script>alert('Maaf password lama anda salah silahkan coba lagi !');document.location='".site_url('Ubahpass')."'</script>";
			}
		}
	}

}
