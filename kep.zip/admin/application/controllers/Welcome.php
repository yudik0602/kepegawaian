<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('M_karyawan');
		$this->load->model('M_cuti');
		$this->load->model('M_resign');
		$this->load->model('M_rekrutment');
		if(!isset($_SESSION['log'])){header("location:".site_url("login"));}
	}
	
	public function index()
	{
		$data['kar']=$this->M_karyawan->cari_karyawan("count(*) as kar","")->row_array(0);
		$data['cut']=$this->M_cuti->cari_cuti("count(*) as cut","")->row_array(0);
		$data['res']=$this->M_resign->cari_resign("count(*) as res","")->row_array(0);
		$data['rek']=$this->M_rekrutment->cari_rekrutment("count(*) as res","")->row_array(0);
		$data['menu']="Beranda";
		$this->load->view('include/header',$data);
		$this->load->view('include/body');
		$this->load->view('include/footer');
	}
}
