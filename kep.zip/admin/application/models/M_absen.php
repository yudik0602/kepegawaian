<?php
class M_absen extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	public function cari_absen($kolom,$kriteria)
	{
		return $this->db->query("select $kolom from tb_absen inner join tb_karyawan on tb_absen.nik=tb_karyawan.nik $kriteria");
	}
	public function tambah_absen()
	{
		return $this->db->insert('tb_absen',array(
			'nik'=>$this->nik,
			'tanggal'=>$this->tanggal,
			'masuk'=>$this->masuk,
			'pulang'=>$this->pulang,
			'status_kehadiran'=>$this->status_kehadiran,
			'foto'=>$this->foto
		));
	}
	public function ubah_absen($id)
	{
		$this->db->where('id_absen', $id);
		return $this->db->update('tb_absen',array(		
			'nik'=>$this->nik,
			'tanggal'=>$this->tanggal,
			'masuk'=>$this->masuk,
			'pulang'=>$this->pulang,
			'status_kehadiran'=>$this->status_kehadiran,
			'foto'=>$this->foto
		));
	}
	
	public function hapus_absen($id)
	{
		$this->db->where('id_absen',$id);
		$this->db->delete('tb_absen');
		return $this->db->affected_rows();
	}

}