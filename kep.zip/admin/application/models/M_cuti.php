<?php
class M_cuti extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	public function cari_cuti($kolom,$kriteria)
	{
		return $this->db->query("select $kolom from tb_cuti inner join tb_karyawan on tb_cuti.nik=tb_karyawan.nik $kriteria");
	}
	public function tambah_cuti()
	{
		return $this->db->insert('tb_cuti',array(
			'nik'=>$this->nik,
			'kategori_cuti'=>$this->kategori_cuti,
			'dari_tgl'=>$this->dari_tgl,
			'sampai_tgl'=>$this->sampai_tgl,
			'lama_cuti'=>$this->lama_cuti,
			'keterangan'=>$this->keterangan,
			'status_cuti'=>$this->status_cuti,
			'tgl_simpan'=>$this->tgl_simpan,
			'ket_val'=>$this->ket_val
		));
	}
	public function ubah_cuti($id)
	{
		$this->db->where('id_cuti', $id);
		return $this->db->update('tb_cuti',array(		
			'kategori_cuti'=>$this->kategori_cuti,
			'dari_tgl'=>$this->dari_tgl,
			'sampai_tgl'=>$this->sampai_tgl,
			'lama_cuti'=>$this->lama_cuti,
			'keterangan'=>$this->keterangan,
			'status_cuti'=>$this->status_cuti,
			'tgl_simpan'=>$this->tgl_simpan
		));
	}
	public function terima_cutih($id)
	{
		$this->db->where('id_cuti', $id);
		return $this->db->update('tb_cuti',array(		
			'status_cuti'=>'Divalidasi HRD'
		));
	}
	public function tolak_cutih($id)
	{
		$this->db->where('id_cuti', $id);
		return $this->db->update('tb_cuti',array(	
			'ket_val'=>$this->ket_val,
			'status_cuti'=>'Ditolak HRD'
		));
	}
	public function terima_cutid($id)
	{
		$this->db->where('id_cuti', $id);
		return $this->db->update('tb_cuti',array(		
			'status_cuti'=>'Divalidasi Direktur'
		));
	}
	public function tolak_cutid($id)
	{
		$this->db->where('id_cuti', $id);
		return $this->db->update('tb_cuti',array(	
			'ket_val'=>$this->ket_val,		
			'status_cuti'=>'Ditolak Direktur'
		));
	}
	public function hapus_cuti($id)
	{
		$this->db->where('id_cuti',$id);
		$this->db->delete('tb_cuti');
		return $this->db->affected_rows();
	}

}