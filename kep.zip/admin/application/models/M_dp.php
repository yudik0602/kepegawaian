<?php
class M_dp extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	public function cari_dp($kolom,$kriteria)
	{
		return $this->db->query("select $kolom from tb_dp inner join tb_karyawan on tb_dp.nik=tb_karyawan.nik $kriteria");
	}
	public function tambah_dp()
	{
		return $this->db->insert('tb_dp',array(
			'nik'=>$this->nik,
			'dari_jabatan'=>$this->dari_jabatan,
			'ke_jabatan'=>$this->ke_jabatan,
			'alasan'=>$this->alasan,
			'status_dp'=>$this->status_dp,
			'tgl_simpan'=>$this->tgl_simpan,
			'tgl_dp'=>$this->tgl_dp
		));
	}
	public function ubah_dp($id)
	{
		$this->db->where('id_dp', $id);
		return $this->db->udpate('tb_dp',array(		
			'dari_jabatan'=>$this->dari_jabatan,
			'ke_jabatan'=>$this->ke_jabatan,
			'alasan'=>$this->alasan,
			'status_dp'=>$this->status_dp,
			'tgl_simpan'=>$this->tgl_simpan,
			'tgl_dp'=>$this->tgl_dp
		));
	}
	
	public function terima_dph($id)
	{
		$this->db->where('id_dp', $id);
		return $this->db->udpate('tb_dp',array(		
			'status_dp'=>'Divalidasi HRD'
		));
	}
	public function tolak_dph($id)
	{
		$this->db->where('id_dp', $id);
		return $this->db->udpate('tb_dp',array(		
			'status_dp'=>'Ditolak HRD'
		));
	}
	public function terima_rdp($id)
	{
		$this->db->where('id_dp', $id);
		return $this->db->udpate('tb_dp',array(		
			'status_dp'=>'Divalidasi Direktur'
		));
	}
	public function tolak_rdp($id)
	{
		$this->db->where('id_dp', $id);
		return $this->db->udpate('tb_dp',array(		
			'status_dp'=>'Ditolak Direktur'
		));
	}
	
	public function hapus_dp($id)
	{
		$this->db->where('id_dp',$id);
		$this->db->delete('tb_dp');
		return $this->db->affected_rows();
	}

}