<?php
class M_gaji extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	public function cari_gaji($kolom,$kriteria)
	{
		return $this->db->query("select $kolom from tb_gaji $kriteria");
	}
	public function tambah_gaji()
	{
		return $this->db->insert('tb_gaji',array(
			'nik'=>$this->nik,
			'bln_gaji'=>$this->bln_gaji,
			'thn_gaji'=>$this->thn_gaji,
			'ttl_kehadiran'=>$this->ttl_kehadiran,
			'gapok'=>$this->gapok,
			'uang_makan'=>$this->uang_makan,
			'uang_transport'=>$this->uang_transport,
			'bpjs_kesehatan'=>$this->bpjs_kesehatan,
			'bpjs_ketenagakerjaan'=>$this->bpjs_ketenagakerjaan,
			'total'=>$this->total,
			'tgl_simpan'=>$this->tgl_simpan
		));
	}
	public function ubah_gaji($id)
	{
		$this->db->where('id_gaji', $id);
		return $this->db->update('tb_gaji',array(		
			'ttl_kehadiran'=>$this->ttl_kehadiran,
			'gapok'=>$this->gapok,
			'uang_makan'=>$this->uang_makan,
			'uang_transport'=>$this->uang_transport,
			'bpjs_kesehatan'=>$this->bpjs_kesehatan,
			'bpjs_ketenagakerjaan'=>$this->bpjs_ketenagakerjaan,
			'total'=>$this->total
		));
	}
	public function hapus_gaji($id)
	{
		$this->db->where('id_gaji',$id);
		$this->db->delete('tb_gaji');
		return $this->db->affected_rows();
	}

}