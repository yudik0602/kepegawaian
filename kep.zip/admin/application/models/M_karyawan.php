<?php
class M_karyawan extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	public function cari_karyawan($kolom,$kriteria)
	{
		return $this->db->query("select $kolom from tb_karyawan $kriteria");
	}
	public function tambah_karyawan()
	{
		return $this->db->insert('tb_karyawan',array(
			'nik'=>$this->nik,
			'no_ktp'=>$this->no_ktp,
			'nama'=>$this->nama,
			'no_hp'=>$this->no_hp,
			'alamat'=>$this->alamat,
			'email'=>$this->email,
			'status'=>$this->status,
			'tempat_lahir'=>$this->tempat_lahir,
			'tgl_lahir'=>$this->tgl_lahir,
			'jenis_kelamin'=>$this->jenis_kelamin,
			'agama'=>$this->agama,
			'gol_darah'=>$this->gol_darah,
			'pendidikan'=>$this->pendidikan,
			'jabatan'=>$this->jabatan,
			'foto'=>$this->foto,
			'lam_ijazah'=>$this->lam_ijazah,
			'lam_kk'=>$this->lam_kk,
			'lam_ktp'=>$this->lam_ktp,
			'gaji_pokok'=>$this->gaji_pokok,
			'uang_makan'=>$this->uang_makan,
			'uang_transport'=>$this->uang_transport,
			'bpjs_kesehatan'=>$this->bpjs_kesehatan,
			'bpjs_ketenagakerjaan'=>$this->bpjs_ketenagakerjaan,
			'tgl_masuk'=>$this->tgl_masuk,
			'tgl_simpan'=>$this->tgl_simpan,
			'status_kerja'=>$this->status_kerja
		));
	}
	public function ubah_karyawan($id)
	{
		$this->db->where('nik', $id);
		return $this->db->update('tb_karyawan',array(		
			'no_ktp'=>$this->no_ktp,
			'nama'=>$this->nama,
			'no_hp'=>$this->no_hp,
			'alamat'=>$this->alamat,
			'email'=>$this->email,
			'status'=>$this->status,
			'tempat_lahir'=>$this->tempat_lahir,
			'tgl_lahir'=>$this->tgl_lahir,
			'jenis_kelamin'=>$this->jenis_kelamin,
			'agama'=>$this->agama,
			'gol_darah'=>$this->gol_darah,
			'pendidikan'=>$this->pendidikan,
			'jabatan'=>$this->jabatan,
			'foto'=>$this->foto,
			'lam_ijazah'=>$this->lam_ijazah,
			'lam_kk'=>$this->lam_kk,
			'lam_ktp'=>$this->lam_ktp,
			'gaji_pokok'=>$this->gaji_pokok,
			'uang_makan'=>$this->uang_makan,
			'uang_transport'=>$this->uang_transport,
			'bpjs_kesehatan'=>$this->bpjs_kesehatan,
			'bpjs_ketenagakerjaan'=>$this->bpjs_ketenagakerjaan,
			'tgl_masuk'=>$this->tgl_masuk,
			'tgl_simpan'=>$this->tgl_simpan
		));
	}
	public function hapus_karyawan($id)
	{
		$this->db->where('nik',$id);
		$this->db->delete('tb_karyawan');
		return $this->db->affected_rows();
	}

}