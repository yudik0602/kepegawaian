<?php
class M_pengguna extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	public function cari_pengguna($kolom,$kriteria)
	{
		return $this->db->query("select $kolom from tb_pengguna $kriteria");
	}
	public function tambah_pengguna()
	{
		return $this->db->insert('tb_pengguna',array(
			'nik'=>$this->nik,
			'password'=>$this->password,
			'akses'=>$this->akses,
			'tgl_simpan'=>$this->tgl_simpan
		));
	}
	public function ubah_pengguna($id)
	{
		$this->db->where('nik', $id);
		return $this->db->update('tb_pengguna',array(		
			'nik'=>$this->nik,
			'akses'=>$this->akses,
			'tgl_simpan'=>$this->tgl_simpan
		));
	}
	public function ubah_pass($id)
	{
		$this->db->where('nik', $id);
		return $this->db->update('tb_pengguna',array(
			'password'=>$this->password
		));
	}
	public function hapus_pengguna($id)
	{
		$this->db->where('nik',$id);
		$this->db->delete('tb_pengguna');
		return $this->db->affected_rows();
	}

}