<?php
class M_penugasan extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	public function cari_penugasan($kolom,$kriteria)
	{
		return $this->db->query("select $kolom from tb_penugasan inner join tb_karyawan on tb_penugasan.nik=tb_karyawan.nik $kriteria");
	}
	public function tambah_penugasan()
	{
		return $this->db->insert('tb_penugasan',array(
			'nik'=>$this->nik,
			'keterangan'=>$this->keterangan,
			'dari_tgl'=>$this->dari_tgl,
			'sampai_tgl'=>$this->sampai_tgl,
			'status_penugasan'=>$this->status_penugasan,
			'tgl_penugasan'=>$this->tgl_penugasan
		));
	}
	public function ubah_penugasan($id)
	{
		$this->db->where('id_penugasan', $id);
		return $this->db->update('tb_penugasan',array(		
			'dari_tgl'=>$this->dari_tgl,
			'sampai_tgl'=>$this->sampai_tgl,
			'keterangan'=>$this->keterangan,
			'tgl_penugasan'=>$this->tgl_penugasan
		));
	}
	public function terima_penugasand($id)
	{
		$this->db->where('id_penugasan', $id);
		return $this->db->update('tb_penugasan',array(		
			'status_penugasan'=>'Divalidasi Direktur'
		));
	}
	public function tolak_penugasand($id)
	{
		$this->db->where('id_penugasan', $id);
		return $this->db->update('tb_penugasan',array(		
			'status_penugasan'=>'Ditolak Direktur'
		));
	}
	public function hapus_penugasan($id)
	{
		$this->db->where('id_penugasan',$id);
		$this->db->delete('tb_penugasan');
		return $this->db->affected_rows();
	}

}