<?php
class M_phk extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	public function cari_phk($kolom,$kriteria)
	{
		return $this->db->query("select $kolom from tb_phk inner join tb_karyawan on tb_phk.nik=tb_karyawan.nik $kriteria");
	}
	public function tambah_phk()
	{
		return $this->db->insert('tb_phk',array(
			'nik'=>$this->nik,
			'keterangan_phk'=>$this->keterangan_phk,
			'lampiran'=>$this->lampiran,
			'status_phk'=>$this->status_phk,
			'tgl_simpan'=>$this->tgl_simpan,
			'tgl_phk'=>$this->tgl_phk
		));
	}
	public function ubah_phk($id)
	{
		$this->db->where('id_phk', $id);
		return $this->db->update('tb_phk',array(		
			'keterangan_phk'=>$this->keterangan_phk,
			'lampiran'=>$this->lampiran,
			'status_phk'=>$this->status_phk,
			'tgl_simpan'=>$this->tgl_simpan,
			'tgl_phk'=>$this->tgl_phk
		));
	}
	
	public function terima_phkh($id)
	{
		$this->db->where('id_phk', $id);
		return $this->db->update('tb_phk',array(		
			'status_phk'=>'Divalidasi HRD'
		));
	}
	public function tolak_phkh($id)
	{
		$this->db->where('id_phk', $id);
		return $this->db->update('tb_phk',array(		
			'status_phk'=>'Ditolak HRD'
		));
	}
	public function terima_phkd($id)
	{
		$this->db->where('id_phk', $id);
		return $this->db->update('tb_phk',array(		
			'status_phk'=>'Divalidasi Direktur'
		));
	}
	public function tolak_phkd($id)
	{
		$this->db->where('id_phk', $id);
		return $this->db->update('tb_phk',array(		
			'status_phk'=>'Ditolak Direktur'
		));
	}
	
	public function hapus_phk($id)
	{
		$this->db->where('id_phk',$id);
		$this->db->delete('tb_phk');
		return $this->db->affected_rows();
	}

}