<?php
class M_rekrutment extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	public function cari_rekrutment($kolom,$kriteria)
	{
		return $this->db->query("select $kolom from tb_rekrutment $kriteria");
	}
	public function tambah_rekrutment()
	{
		return $this->db->insert('tb_rekrutment',array(
			'nama'=>$this->nama,
			'telp'=>$this->telp,
			'alamat'=>$this->alamat,
			'email'=>$this->email,
			'status_lamaran'=>$this->status_lamaran,
			'cv'=>$this->cv,
			'tanggal_input'=>$this->tanggal_input
		));
	}
	public function ubah_rekrutment($id)
	{
		$this->db->where('id_rekrutment', $id);
		return $this->db->update('tb_rekrutment',array(		
			'nama'=>$this->nama,
			'telp'=>$this->telp,
			'alamat'=>$this->alamat,
			'email'=>$this->email,
			'status_lamaran'=>$this->status_lamaran,
			'cv'=>$this->cv,
			'tanggal_input'=>$this->tanggal_input
		));
	}
	public function hapus_rekrutment($id)
	{
		$this->db->where('id_rekrutment',$id);
		$this->db->delete('tb_rekrutment');
		return $this->db->affected_rows();
	}

}