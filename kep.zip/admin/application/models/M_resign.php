<?php
class M_resign extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	public function cari_resign($kolom,$kriteria)
	{
		return $this->db->query("select $kolom from tb_resign inner join tb_karyawan on tb_resign.nik=tb_karyawan.nik $kriteria");
	}
	public function tambah_resign()
	{
		return $this->db->insert('tb_resign',array(
			'nik'=>$this->nik,
			'alasan_resign'=>$this->alasan_resign,
			'lampiran'=>$this->lampiran,
			'status_resign'=>$this->status_resign,
			'tgl_simpan'=>$this->tgl_simpan,
			'tgl_resign'=>$this->tgl_resign
		));
	}
	public function ubah_resign($id)
	{
		$this->db->where('id_resign', $id);
		return $this->db->update('tb_resign',array(		
			'alasan_resign'=>$this->alasan_resign,
			'lampiran'=>$this->lampiran,
			'status_resign'=>$this->status_resign,
			'tgl_simpan'=>$this->tgl_simpan,
			'tgl_resign'=>$this->tgl_resign
		));
	}
	public function terima_resignh($id)
	{
		$this->db->where('id_resign', $id);
		return $this->db->update('tb_resign',array(		
			'status_resign'=>'Divalidasi'
		));
	}
	public function tolak_resignh($id)
	{
		$this->db->where('id_resign', $id);
		return $this->db->update('tb_resign',array(		
			'status_resign'=>'Ditolak'
		));
	}
	public function hapus_resign($id)
	{
		$this->db->where('id_resign',$id);
		$this->db->delete('tb_resign');
		return $this->db->affected_rows();
	}

}