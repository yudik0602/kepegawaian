<?php
class M_rp extends CI_Model 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	public function cari_rp($kolom,$kriteria)
	{
		return $this->db->query("select $kolom from tb_rp inner join tb_karyawan on tb_rp.nik=tb_karyawan.nik $kriteria");
	}
	public function tambah_rp()
	{
		return $this->db->insert('tb_rp',array(
			'nik'=>$this->nik,
			'keterangan'=>$this->keterangan,
			'lampiran'=>$this->lampiran,
			'status_rp'=>$this->status_rp,
			'tgl_simpan'=>$this->tgl_simpan,
			'tgl_rp'=>$this->tgl_rp
		));
	}
	public function ubah_rp($id)
	{
		$this->db->where('id_rp', $id);
		return $this->db->update('tb_rp',array(		
			'keterangan'=>$this->keterangan,
			'lampiran'=>$this->lampiran,
			'status_rp'=>$this->status_rp,
			'tgl_simpan'=>$this->tgl_simpan,
			'tgl_rp'=>$this->tgl_rp
		));
	}
	
	public function terima_rph($id)
	{
		$this->db->where('id_rp', $id);
		return $this->db->update('tb_rp',array(		
			'status_rp'=>'Divalidasi HRD'
		));
	}
	public function tolak_rph($id)
	{
		$this->db->where('id_rp', $id);
		return $this->db->update('tb_rp',array(		
			'status_rp'=>'Ditolak HRD'
		));
	}
	public function terima_rpd($id)
	{
		$this->db->where('id_rp', $id);
		return $this->db->update('tb_rp',array(		
			'status_rp'=>'Divalidasi Direktur'
		));
	}
	public function tolak_rpd($id)
	{
		$this->db->where('id_rp', $id);
		return $this->db->update('tb_rp',array(		
			'status_rp'=>'Ditolak Direktur'
		));
	}
	
	public function hapus_rp($id)
	{
		$this->db->where('id_rp',$id);
		$this->db->delete('tb_rp');
		return $this->db->affected_rows();
	}

}