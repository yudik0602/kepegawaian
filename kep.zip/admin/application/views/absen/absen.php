<style>
.table-responsive {
	display: block;
	width: 100%;
	overflow-x: auto;
	-webkit-overflow-scrolling: touch;
	-ms-overflow-style: -ms-autohiding-scrollbar; 
}

#mapid {
	aspect-ratio: 1/1;
	width: 100%;
	border-radius: 10px;
	z-index: 0;
}
</style>
<link rel="stylesheet" href="<?php echo config_item('assets'); ?>leaflet/leaflet.css">
<script src="<?php echo config_item('assets'); ?>leaflet/leaflet.js"></script>
<div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1><?php echo $menu;?></h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo site_url('Welcome');?>">Dashboard</a></li>
					<li class="active"><?php echo $menu;?></li>
				</ol>
			</div>
		</div>
	</div>
</div>

<div class="content mt-3">
	<div class="animated fadeIn">

		<div class="row">
			<div class="col-md-5">
				<div class="card">
					<div class="card-header bg-success">
						<strong class="card-title" style="color:white">Form <?php echo $menu;?></strong>
					</div>
					<div class="card-body">
						<!-- Credit Card -->
						<div id="pay-invoice">
							<div class="card-body">
								<form method="post" enctype="multipart/form-data">
									<div class="form-group">
										<label for="cc-number" class="control-label mb-1">NIK</label>
										<select class="form-control" name="nik" id="nik" required>
											<?php
												foreach($nik->result_array() as $ops){
											?>
												<option <?php if($aksi=="ubah"){if($cd['nik']==$ops['nik']){echo "selected=''";}}?> value="<?php echo $ops['nik'];?>"><?php echo $ops['nik']." - ".$ops['nama'];?></option>
											<?php }?>
										</select>
									</div>
									
									<div class="form-group">
										<div style="margin-left:-66px" id="my_camera"></div>
									</div>
									
									<div class="form-group">
										<label for="cc-number" class="control-label mb-1">Langlitude</label>
										<input type="text" name="latitude" class="form-control" required readonly id="langli">
									</div>
									
									<div class="form-group">
										<label for="cc-number" class="control-label mb-1">Longlitude</label>
										<input type="text" name="longitude" class="form-control" required readonly id="longli">
									</div>
									<div class="form-group">
									</div>
										<div id="mapid"></div>
									<div hidden id="hasil" style="height:250px;overflow:auto;width:60%"></div>
									<div>
										<button type="submit" class="btn btn-md btn-success" onclick="simpan()">
											<i class="fa fa-save fa-lg"></i>&nbsp;
											<span id="payment-button-sending">Simpan</span>
										</button>
										<button type="reset" class="btn btn-md btn-danger" onclick="document.location='<?php echo site_url('Pengguna');?>'">
											<i class="fa fa-refresh fa-lg"></i>&nbsp;
											<span id="payment-button-sending">Batal</span>
										</button>
									</div>
								</form>
							</div>
						</div>

					</div>
				</div> <!-- .card -->

			</div>
			<!--/.col-->
			
			<div class="col-md-7">
				<div class="card">
					<div class="card-header"><strong>Tabel <?php echo $menu;?></strong></div>
					<div class="card-body">
					<div class="table-responsive">
						 <table id="bootstrap-data-table-export" class="table table-striped table-bordered" style="font-size:12px;">
							<thead>
								<tr>
									<th width="5%">No</th>
									<th width="25%">NIK</th>
									<th width="15%">Nama</th>
									<th width="15%">Tgl</th>
									<th width="15%">Jam</th>
									<th width="15%">Ket</th>
									<th width="15%">Foto</th>
									<th width="15%">Lokasi</th>
								</tr>
							</thead>
							<tbody>
							 <?php
								$i=1;
								foreach($tampil->result_array() as $res){
							  ?>
								<tr>
									<td><?php echo $i++;?></td>
									<td><?php echo $res['nik'];?></td>
									<td><?php echo $res['nama'];?></td>
									<td><?php echo $res['tanggal'];?></td>
									<td><?php echo $res['jam'];?></td>
									<td><?php echo $res['ket'];?></td>
									<td><a href="ajax/upload/<?php echo $res['fot'];?>">Foto</a></td>
									<td><a data-toggle="modal" data-target="#exampleModal" class="btn btn-info btn-sm" onclick="showMap(<?php echo $res['langli'];?>,<?php echo $res['longli'];?>)"><?php echo $res['langli'];?>,<?php echo $res['longli'];?></a></td>
								</tr>
								<?php }?>
							</tbody>
						</table>
					</div>
					</div>
				</div>
			</div>
	<script>
	function getLocation() {
		if (navigator.geolocation) {
			navigator.geolocation.getCurrentPosition(showPosition, showError);
		} else {
			alert('Your device is not support!');
		}
	}

	function showPosition(data) {
		document.getElementById('langli').value = data.coords.latitude
		document.getElementById('longli').value = data.coords.longitude
	}

	function showError(error) {
		let error_message = ''
		switch (error.code) {
			case error.PERMISSION_DENIED:
				error_message = "User denied the request for Geolocation."
				break;
			case error.POSITION_UNAVAILABLE:
				error_message = "Location information is unavailable."
				break;
			case error.TIMEOUT:
				error_message = "The request to get user location timed out."
				break;
			case error.UNKNOWN_ERROR:
				error_message = "An unknown error occurred."
				break;
		}
		alert(error_message)
	}           
   getLocation()
</script>
<script src="<?php echo config_item('assets'); ?>/webcam.js"></script>
<script language="JavaScript">
        Webcam.set({
            width: 450,
            height: 240,
            image_format: 'jpeg',
            jpeg_quality: 120
        });
        Webcam.attach('#my_camera');
   
        function simpan(){
            event.preventDefault();
            var image = '';
            var nik = $('#nik').val();
            var langli = $('#langli').val();
            var longli = $('#longli').val();
            Webcam.snap(function (data_uri) {
                image = data_uri;
            });
            $.ajax({
                url: 'ajax/action.php',
                type: 'POST',
                data: {
                    nik: nik,
                    langli: langli,
                    longli: longli,
                    image: image
                },
                success: function (data) {
                    $("#hasil").html(data+"<br>"+$("#hasil").html());  
                }
            })
        };

		function getlokasi() {
			if (navigator.geolocation) {
				navigator.geolocation.getCurrentPosition(showMap);    
			}
		}
	
	var mymap = ''
	function showMap(posisi) {
		var langli=posisi.coords.latitude;
		var longli=posisi.coords.longitude;
		if (mymap) {
			mymap.remove();
			mymap = undefined
		}
		mymap = L.map("mapid").setView(
			[langli, longli],
			13
		);
		L.tileLayer(
			"https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
				maxZoom: 18,
				attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
					'<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
					'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
				id: "mapbox/streets-v11",
				tileSize: 512,
				zoomOffset: -1,
			}
		).addTo(mymap);
		L.marker([
			langli, longli
		])
			.addTo(mymap)
			.bindPopup("Location");
	}
	getlokasi();
</script>