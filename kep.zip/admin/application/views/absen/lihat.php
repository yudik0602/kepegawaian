<style>
.table-responsive {
	display: block;
	width: 100%;
	overflow-x: auto;
	-webkit-overflow-scrolling: touch;
	-ms-overflow-style: -ms-autohiding-scrollbar; 
}

#mapid {
	aspect-ratio: 1/1;
	width: 100%;
	border-radius: 10px;
	z-index: 0;
}
</style>
<link rel="stylesheet" href="<?php echo config_item('assets'); ?>leaflet/leaflet.css">
<script src="<?php echo config_item('assets'); ?>leaflet/leaflet.js"></script>
<div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1><?php echo $menu;?></h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo site_url('Welcome');?>">Dashboard</a></li>
					<li class="active"><?php echo $menu;?></li>
				</ol>
			</div>
		</div>
	</div>
</div>

<div class="content mt-3">
	<div class="animated fadeIn">

		<div class="row">
			<!--/.col-->
			<div class="col-md-12" id="tampil" style="display:none">
				<div class="form-example-wrap">
				<h5 class="alert alert-danger text-center">Lokasi Absen</h5>
					<div id="mapid" style="height:250px"></div>
				</div>
			</div>
			<div class="col-md-12">
				<div class="card">
					<div class="card-header"><strong>Tabel <?php echo $menu;?></strong></div>
					<div class="card-body">
					<div class="table-responsive">
						 <table id="bootstrap-data-table-export" class="table table-striped table-bordered" style="font-size:12px;">
							<thead>
								<tr>
									<th width="5%">No</th>
									<th width="25%">NIK</th>
									<th width="15%">Nama</th>
									<th width="15%">Tgl</th>
									<th width="15%">Jam</th>
									<th width="15%">Ket</th>
									<th width="15%">Foto</th>
									<th width="15%">Lokasi</th>
								</tr>
							</thead>
							<tbody>
							 <?php
								$i=1;
								foreach($tampil->result_array() as $res){
							  ?>
								<tr>
									<td><?php echo $i++;?></td>
									<td><?php echo $res['nik'];?></td>
									<td><?php echo $res['nama'];?></td>
									<td><?php echo $res['tanggal'];?></td>
									<td><?php echo $res['jam'];?></td>
									<td><?php echo $res['ket'];?></td>
									<td><a href="ajax/upload/<?php echo $res['fot'];?>">Foto</a></td>
									<td><a data-toggle="modal" data-target="#exampleModal" class="btn btn-info btn-sm" onclick="showMap(<?php echo $res['langli'];?>,<?php echo $res['longli'];?>)"><?php echo $res['langli'];?>,<?php echo $res['longli'];?></a></td>
								</tr>
								<?php }?>
							</tbody>
						</table>
					</div>
					</div>
				</div>
			</div>
			
			<script>
			var mymap = ''
            function showMap(latitude, longitude) {
				var x = document.getElementById("tampil");
				  if (x.style.display === "none") {
					x.style.display = "block";
				  } else {
					x.style.display = "none";
				  }
    
                //remove map and render the new map
                if (mymap) {
                    mymap.remove();
                    mymap = undefined
                }
    
                //make map area
                mymap = L.map("mapid").setView(
                    [latitude, longitude],
                    13
                );
    
                //setting maps using api mapbox not google maps, register and get tokens
                L.tileLayer(
                    "https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
                        maxZoom: 18,
                        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
                            '<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
                            'Imagery � <a href="https://www.mapbox.com/">Mapbox</a>',
                        id: "mapbox/streets-v11",
                        tileSize: 512,
                        zoomOffset: -1,
                    }
                ).addTo(mymap);
    
    
                //add marker position with variabel latitude and longitude
                L.marker([
                    latitude, longitude
                ])
                    .addTo(mymap)
                    .bindPopup("Location");
            }
	</script>