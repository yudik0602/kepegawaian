<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>PT GINTING JAYA ENERGI</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
		============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
    <!-- Google Fonts
		============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700,900" rel="stylesheet">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo config_item('assets'); ?>css/bootstrap.min.css">
    <!-- Bootstrap CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo config_item('assets'); ?>css/font-awesome.min.css">
    <!-- owl.carousel CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo config_item('assets'); ?>css/owl.carousel.css">
    <link rel="stylesheet" href="<?php echo config_item('assets'); ?>css/owl.theme.css">
    <link rel="stylesheet" href="<?php echo config_item('assets'); ?>css/owl.transitions.css">
    <!-- meanmenu CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo config_item('assets'); ?>css/meanmenu/meanmenu.min.css">
    <!-- animate CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo config_item('assets'); ?>css/animate.css">
    <!-- normalize CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo config_item('assets'); ?>css/normalize.css">
    <!-- mCustomScrollbar CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo config_item('assets'); ?>css/scrollbar/jquery.mCustomScrollbar.min.css">
    <!-- jvectormap CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo config_item('assets'); ?>css/jvectormap/jquery-jvectormap-2.0.3.css">
    <!-- notika icon CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo config_item('assets'); ?>css/notika-custom-icon.css">
    <!-- wave CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo config_item('assets'); ?>css/wave/waves.min.css">
    <!-- main CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo config_item('assets'); ?>css/main.css">
    <!-- style CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo config_item('assets'); ?>style.css">
    <!-- responsive CSS
		============================================ -->
    <link rel="stylesheet" href="<?php echo config_item('assets'); ?>css/responsive.css">
    <!-- modernizr JS
		============================================ -->
    <script src="<?php echo config_item('assets'); ?>js/vendor/modernizr-2.8.3.min.js"></script>
	 <!-- Data Table JS
		============================================ -->
    <link rel="stylesheet" href="<?php echo config_item('assets'); ?>css/jquery.dataTables.min.css">
	<link rel="stylesheet" href="<?php echo config_item('assets'); ?>css/bootstrap-select/bootstrap-select.css">
</head>
<!-- Breadcomb area Start-->
	<style>	
	@media print{
		.show_print{display:block !important}
		.hide_print{display:none !important}
		.no-print {visibility: hidden;}
	}
	</style>
    <!-- Data Table area Start-->
    <div class="data-table-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				
                    <div class="data-table-list">
					<div>
						<h3>PT GINTING JAYA ENERGI</h3>
						<h5>LAPORAN DATA KARYAWAN</h5>
						<p>PERIODE LAPORAN : <?php echo date("d-M-Y");?></p>
					</div>
                        
                             <table class="table table-striped table-bordered">
                               <thead>
                                    <tr>
                                        <th style="font-size:12px">No</th>
                                        <th style="font-size:12px">NIK</th>
                                        <th style="font-size:12px">Nama</th>
                                        <th style="font-size:12px">No HP</th>
                                        <th style="font-size:12px">TTL</th>
                                        <th style="font-size:12px">Jabatan</th>
                                        <th style="font-size:12px">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
                                        $i=1;
                                        foreach($tampil->result_array() as $res){
                                ?>
                                    <tr>
										<td style="font-size:12px"><?php echo $i++;?></td>
                                        <td style="font-size:12px"><?php echo $res['nik'];?></td>
                                        <td style="font-size:12px"><?php echo $res['nama'];?></td>
                                        <td style="font-size:12px"><?php echo $res['no_hp'];?></td>
                                        <td style="font-size:12px"><?php echo $res['tempat_lahir']."/".$res['tgl_lahir'];?></td>
                                        <td style="font-size:12px"><?php echo $res['jabatan'];?></td>
                                        <td style="font-size:12px"><?php echo $res['status_kerja'];?></td>
                                    </tr>
                                        <?php }?>
                                </tbody>
                            </table>
                        <a class="btn btn-info hide_print" onclick="window.print()">CETAK</a>
                    </div>
                </div>
            </div>
			
        </div>
    </div>
    <!-- Data Table area End-->