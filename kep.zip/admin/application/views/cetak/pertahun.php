<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SISTEM INFORMASI KEPEGAWAIAN</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="<?php echo config_item('vendors'); ?>bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo config_item('vendors'); ?>font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo config_item('vendors'); ?>themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="<?php echo config_item('vendors'); ?>flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="<?php echo config_item('vendors'); ?>selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="<?php echo config_item('vendors'); ?>jqvmap/dist/jqvmap.min.css">
    <link rel="stylesheet" href="<?php echo config_item('vendors'); ?>/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo config_item('vendors'); ?>/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">


    <link rel="stylesheet" href="<?php echo config_item('assets'); ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo config_item('vendors'); ?>chosen/chosen.min.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <script src="<?php echo config_item('assets'); ?>assets/js/jquery-2.1.4.min.js"></script>

</head>
<style>	
	@media print{
		.show_print{display:block !important}
		.hide_print{display:none !important}
		.no-print {visibility: hidden;}
	}
</style>
<div class="content mt-3">
	<div class="animated fadeIn">
   <div class="col-md-12">
		<div class="card">
			<div class="card-body">
			<div>
				<h3>PT TAWAN CEMERLANG ABADI</h3>
				<h5>LAPORAN DATA CUTI</h5>
				<p>PERIODE LAPORAN : <?php if(isset($_GET['tahun'])){echo $_GET['tahun'];}?></p>
			</div>
			<div class="table-responsive">
			<?php if(isset($_GET['tahun'])){?>
				
					<table class="table table-striped table-bordered table-hover" style="font-size:12px;">
							<thead>
								<tr>
									<th width="5%">No</th>
									<th width="15%">NIK</th>
									<th width="15%">Nama</th>
									<th width="10%">Cuti Ditolak</th>
									<th width="15%">Cuti Diacc</th>
									<th width="15%">Sisa Cuti</th>
								</tr>
							</thead>
							
							<tbody>
							 <?php
								$i=1;
								foreach($tampil->result_array() as $res){
									$tolak=$this->db->query("select count(*) as tolak,sum(lama_cuti) as lama from tb_cuti where nik='$res[nik]' and year(tgl_simpan)='$_GET[tahun]' and status_cuti='Ditolak'")->row_array(0);
									$terima=$this->db->query("select count(*) as terima,sum(lama_cuti) as total from tb_cuti where nik='$res[nik]' and year(tgl_simpan)='$_GET[tahun]' and status_cuti='Divalidasi'")->row_array(0);
									$sisa=12-$terima['total'];
							  ?>
								<tr>
									<td><?php echo $i++;?></td>
									<td><?php echo $res['nik'];?></td>
									<td><?php echo $res['nama'];?></td>
									<td><?php echo $tolak['tolak'];?></td>
									<td><?php echo $terima['terima'];?></td>
									<td><?php echo $sisa." hari";?></td>
								</tr>
								<?php }?>
							</tbody>
							
						</table>
				<a class="btn btn-info hide_print" onclick="window.print()">CETAK</a>
				<?php }?>
			</div>
		</div>
	</div>
	
</div>
</div>
</div>

    <!-- Data Table area End-->