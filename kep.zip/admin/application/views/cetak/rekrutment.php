<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SISTEM INFORMASI KEPEGAWAIAN</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="<?php echo config_item('vendors'); ?>bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo config_item('vendors'); ?>font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo config_item('vendors'); ?>themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="<?php echo config_item('vendors'); ?>flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="<?php echo config_item('vendors'); ?>selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="<?php echo config_item('vendors'); ?>jqvmap/dist/jqvmap.min.css">
    <link rel="stylesheet" href="<?php echo config_item('vendors'); ?>/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo config_item('vendors'); ?>/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">


    <link rel="stylesheet" href="<?php echo config_item('assets'); ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo config_item('vendors'); ?>chosen/chosen.min.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <script src="<?php echo config_item('assets'); ?>assets/js/jquery-2.1.4.min.js"></script>

</head>
<style>	
	@media print{
		.show_print{display:block !important}
		.hide_print{display:none !important}
		.no-print {visibility: hidden;}
	}
</style>
<div class="content mt-3">
	<div class="animated fadeIn">
   <div class="col-md-12">
		<div class="card">
			<div class="card-body">
			<div>
				<h3>PT TAWAN CEMERLANG ABADI</h3>
				<h5>LAPORAN DATA REKRUTMENT</h5>
				<p>PERIODE LAPORAN : <?php if(isset($_GET['awal'])){echo $_GET['awal']." s/d ".$_GET['akhir'];}?></p>
			</div>
			<div class="table-responsive">
			<?php if(isset($_GET['awal'])){?>
				
					<table class="table table-striped table-bordered" style="font-size:12px">
						<thead>
								<tr>
									<th width="5%">No</th>
									<th width="15%">Nama</th>
									<th width="15%">Telepon</th>
									<th width="15%">Alamat</th>
									<th width="15%">Email</th>
									<th width="15%">Status</th>
									<th width="15%">CV</th>
									<th width="15%">Posisi</th>
									<th width="15%">Tanggal</th>
								</tr>
							</thead>
							<tbody>
							 <?php
								$i=1;
								foreach($tampil->result_array() as $res){
							  ?>
								<tr>
									<td><?php echo $i++;?></td>
									<td><?php echo $res['nama'];?></td>
									<td><?php echo $res['telp'];?></td>
									<td><?php echo $res['alamat'];?></td>									
									<td><?php echo $res['email'];?></td>
									<td><a class="<?php if($res['status_lamaran']=='Dikirim'){echo'btn btn-info btn-sm';}if($res['status_lamaran']=='Diterima'){echo'btn btn-success btn-sm';}?>"><?php echo $res['status_lamaran'];?></a></td>
									<td><a target="_blank" href="<?php echo config_item('images')?>/cv/<?php echo $res['cv'];?>"><?php echo $res['cv'];?></a></td>
									<td><?php echo $res['posisi'];?></td>
									<td><?php echo $res['tanggal_input'];?></td>
								</tr>
								<?php }?>
							</tbody>
					</table>
				<a class="btn btn-info hide_print" onclick="window.print()">CETAK</a>
				<?php }?>
			</div>
		</div>
	</div>
	
</div>
</div>
</div>

    <!-- Data Table area End-->