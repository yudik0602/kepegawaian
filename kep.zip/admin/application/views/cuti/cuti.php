<style>
.table-responsive {
	display: block;
	width: 100%;
	overflow-x: auto;
	-webkit-overflow-scrolling: touch;
	-ms-overflow-style: -ms-autohiding-scrollbar; 
}
</style>
<div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1><?php echo $menu;?></h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo site_url('Welcome');?>">Dashboard</a></li>
					<li class="active"><?php echo $menu;?></li>
				</ol>
			</div>
		</div>
	</div>
</div>

<div class="content mt-3">
	<div class="animated fadeIn">

		<div class="row">
			<div class="col-lg-7">
				<div class="card">
					<div class="card-header bg-success">
						<strong class="card-title" style="color:white">Form <?php echo $menu;?></strong>
					</div>
					<div class="card-body">
						<!-- Credit Card -->
						<div id="pay-invoice">
							<div class="card-body">
								<form action="<?php echo $url;?>" method="post" enctype="multipart/form-data">
									<div class="form-group">
										<label for="cc-number" class="control-label mb-1">NIK</label>
										<select class="form-control" name="nik" id="nik" required>
											<?php
												foreach($nik->result_array() as $ops){
											?>
												<option <?php if($aksi=="ubah"){if($cd['nik']==$ops['nik']){echo "selected=''";}}?> value="<?php echo $ops['nik'];?>"><?php echo $ops['nik']." - ".$ops['nama'];?></option>
											<?php }?>
										</select>
									</div>
									<div class="form-group">
										<label for="cc-number" class="control-label mb-1">Kategori Cuti</label>
										<select name="kategori_cuti" id="kategori_cuti" class="form-control">
											<option value="" disabled selected>-- Pilih --</option>
											<option <?php if($aksi=="ubah"){if($cd['kategori_cuti']=="Umum"){echo "selected";}}?>>Umum</option>
											<option <?php if($aksi=="ubah"){if($cd['kategori_cuti']=="Melahirkan"){echo "selected";}}?>>Melahirkan</option>
										</select>
									</div>
									<div class="form-group">
										<label class="control-label mb-1">Dari Tanggal</label>
										<input name="dari_tgl" id="dari_tgl" type="date" class="form-control" required <?php if($aksi=="ubah"){echo 'value="'.$cd['dari_tgl'].'"';}?>>
									</div>
									<div class="form-group">
										<label class="control-label mb-1">Sampai Tanggal</label>
										<input name="sampai_tgl" id="sampai_tgl" type="date" class="form-control" required <?php if($aksi=="ubah"){echo 'value="'.$cd['sampai_tgl'].'"';}?>>
									</div>
									<?php
										include"ajax/kon.php";
										if(isset($_SESSION['nik'])){
											$id=$_SESSION['nik'];
										}if(isset($_SESSION['ubah'])){
											$id=$cd['nik'];
										}
										$tahun=date('Y');
										$foto=mysqli_fetch_array(mysqli_query($con,"select * from tb_karyawan where nik='$id'"));
										$cuti=mysqli_fetch_array(mysqli_query($con,"select sum(lama_cuti) as jumlah_cuti from tb_cuti where nik='$id' and status_cuti='Divalidasi' and year(tgl_simpan)=".$tahun." and kategori_cuti='Umum'"));
										$jatah=12;
										$sisa=0;
										if($cuti['jumlah_cuti']==""){
											$sisa=$jatah;
										}else{
											$sisa=$jatah-$cuti['jumlah_cuti'];
										}
										$kar=mysqli_fetch_array(mysqli_query($con,"select * from tb_karyawan where nik='$_SESSION[nik]'"));
									?>
									
									<div class="form-group row">
										<label class="control-label mb-1  col-md-3">Lama Cuti</label>
										<input name="lama_cuti" id="lama_cuti" type="number" class="form-control col-md-6" required <?php if($aksi=="ubah"){echo 'value="'.$cd['lama_cuti'].'"';}?>>
										<input type="text" readonly hidden name="sisa" id="sisa" required value="<?php echo $sisa;?>">
								
										<button type="button" id="cek_data" class="btn btn-md btn-info" style="margin-left:5px" onclick="pilih()">
											<span id="payment-button-sending">Cek Data</span>
										</button>
									</div>
									
									<div class="form-group">
										<label for="cc-number" class="control-label mb-1">Keterangan</label>
										<textarea class="form-control" rows="6" required name="keterangan"><?php if($aksi=="ubah"){echo $cd['keterangan'];}?></textarea>
									</div>
									
									<div>
										<button type="submit" class="btn btn-md btn-success">
											<i class="fa fa-save fa-lg"></i>&nbsp;
											<span id="payment-button-sending">Simpan</span>
										</button>
										<button type="reset" class="btn btn-md btn-danger" onclick="document.location='<?php echo site_url('Cuti');?>'">
											<i class="fa fa-refresh fa-lg"></i>&nbsp;
											<span id="payment-button-sending">Batal</span>
										</button>
									</div>
								</form>
							</div>
						</div>

					</div>
				</div> <!-- .card -->

			</div>
			<!--/.col-->

			<div class="col-md-5">
				<div class="card">
					<div class="card-header bg-info"><strong style="color:white">INFO KARYAWAN</strong></div>
					<div class="card-body">
					<div class="table-responsive">
						 <table class="table" style="font-size:12px;">
							<tr>
								<th>Foto</th>
								<th> : </th>
								<th><div id="foto"></div><img src="<?php echo config_item('images');?>/foto/<?php echo $kar['foto'];?>" width='150px'></th>
							</tr>
							<tr>
								<th>NIK</th>
								<th> : </th>
								<th><div id="niks"><?php echo $kar['nik'];?></div></th>
							</tr>
							<tr>
								<th>Nama</th>
								<th> : </th>
								<th><div id="nama"><?php echo $kar['nama'];?></div></th>
							</tr>
							<tr>
								<th>Jabatan</th>
								<th> : </th>
								<th><div id="jabatan"><?php echo $kar['jabatan'];?></div></th>
							</tr>
							<tr>
								<th>No HP</th>
								<th> : </th>
								<th><div id="no_hp"><?php echo $kar['no_hp'];?></div></th>
							</tr>
							<tr>
								<th>Email</th>
								<th> : </th>
								<th><div id="email"><?php echo $kar['email'];?></div></th>
							</tr>
							<tr>
								<th>Sisa Cuti</th>
								<th> : </th>
								<th><div id="email"><?php echo $sisa.' hari';?></div></th>
							</tr>
						</table>
					</div>
					</div>
				</div>
			</div>
			<div class="col-md-12">
				<div class="card">
					<div class="card-header"><strong>Tabel <?php echo $menu;?></strong></div>
					<div class="card-body">
					<div class="table-responsive">
						 <table id="bootstrap-data-table-export" class="table table-striped table-bordered" style="font-size:12px;">
							<thead>
								<tr>
									<th width="20%">Aksi</th>
									<th width="5%">No</th>
									<th width="25%">NIK</th>
									<th width="15%">Nama</th>
									<th width="15%">Kategori</th>
									<th width="15%">Keterangan</th>
									<th width="15%">Periode Cuti</th>
									<th width="15%">Lama</th>
									<th width="15%">Status</th>
									<th width="15%">Alasan</th>
								</tr>
							</thead>
							<tbody>
							 <?php
								$i=1;
								foreach($tampil->result_array() as $res){
							  ?>
								<tr>
									<td>
										<?php 
											if($res['status_cuti']=='Diinput'){
										?>
										<a href="<?php echo site_url('Cuti/index/ubah/'.$res['id_cuti'])?>" class="btn btn-sm btn-warning"><i class="menu-icon fa fa-edit"></i></a> <a href="<?php echo site_url('Cuti/hapus/'.$res['id_cuti'])?>" class="btn btn-sm btn-danger"><i class="menu-icon fa fa-close"></i></a>
										<?php }?>
									</td>
									<td><?php echo $i++;?></td>
									<td><?php echo $res['nik'];?></td>
									<td><?php echo $res['nama'];?></td>
									<td><?php echo $res['kategori_cuti'];?></td>
									<td><?php echo $res['keterangan'];?></td>
									<td><?php echo $res['dari_tgl']." s/d ".$res['sampai_tgl'];?></td>
									<td><?php echo $res['lama_cuti']." hari";?></td>
									<td><?php echo $res['status_cuti'];?></td>
									<td><?php echo $res['ket_val'];?></td>
								</tr>
								<?php }?>
							</tbody>
						</table>
					</div>
					</div>
				</div>
			</div>
	<script>
		$(document).ready(function(){
			document.getElementById('nik').focus();
			$('#nik').change(function(){
				if($(this).val() !== '')
				{
					$.ajax({
						url: "ajax/karyawan.php",
						type: "POST",
						cache: false,
						data: "nik="+$(this).val(),
						dataType:'json',
						success: function(json){
							$('#niks').html(json.nik);
							$('#nama').html(json.nama);
							$('#no_hp').html(json.no_hp);
							$('#email').html(json.email);
							$('#jabatan').html(json.jabatan);
							$('#foto').html(json.foto);
						}
					});
				}
				else
				{
					$('#niks').html('<small><i>Tidak ada</i></small>');
					$('#nama').html('<small><i>Tidak ada</i></small>');
					$('#no_hp').html('<small><i>Tidak ada</i></small>');
					$('#email').html('<small><i>Tidak ada</i></small>');
					$('#jabatan').html('<small><i>Tidak ada</i></small>');
					$('#foto').html('<small><i>Tidak ada</i></small>');
				}
			});
			
		});

	function pilih(){
		var currentdate = new Date(); 
		var datetime = currentdate.getFullYear() + "-"+ "0"+(currentdate.getMonth()+1)  + "-"+"0"+ currentdate.getDate();
		var date = new Date();	
		var date1 = new Date();	
		

		var dari=document.getElementById('dari_tgl').value;
		var sampai=document.getElementById('sampai_tgl').value;
		if(sampai<datetime){
			alert('Maaf tidak boleh input tanggal kemarin !'+datetime+ "-/"+dari);
			document.location="<?php echo site_url('Cuti')?>";
			return;
		}
		
		$.ajax({
			type:'POST',
			url:'ajax/cek_cuti.php',
			data:'dari_tgl='+dari+'&sampai_tgl='+sampai,
			success:function(data){
				$('#lama_cuti').val(data);
			}
		});
	}
  </script>