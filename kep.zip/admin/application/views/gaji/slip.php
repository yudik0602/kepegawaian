<style>
.table-responsive {
	display: block;
	width: 100%;
	overflow-x: auto;
	-webkit-overflow-scrolling: touch;
	-ms-overflow-style: -ms-autohiding-scrollbar; 
}
</style>
<div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1><?php echo $menu;?></h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo site_url('Welcome');?>">Dashboard</a></li>
					<li class="active"><?php echo $menu;?></li>
				</ol>
			</div>
		</div>
	</div>
</div>

<div class="content mt-3">
	<div class="animated fadeIn">

		<div class="row">
		<?php if(!isset($_POST['cari'])){?>
			<div class="col-lg-7">
				<div class="card">
					<div class="card-header bg-success">
						<strong class="card-title" style="color:white">Pilih Priode Gaji</strong>
					</div>
					<div class="card-body">
						<!-- Credit Card -->
						<div id="pay-invoice">
							<div class="card-body">
								<form method="post" enctype="multipart/form-data">
									<div class="form-group">
										<label class="control-label mb-1">Bulan</label>
										<select class="form-control input-sm" name="bulan" required>
											<option value="" disabled selected>-- Bulan --</option>
											<option <?php if(isset($_POST['cari'])){if($_POST['bulan']=='1'){echo"selected";}}?> value="1">Januari</option>
											<option <?php if(isset($_POST['cari'])){if($_POST['bulan']=='2'){echo"selected";}}?> value="2">Februari</option>
											<option <?php if(isset($_POST['cari'])){if($_POST['bulan']=='3'){echo"selected";}}?> value="3">Maret</option>
											<option <?php if(isset($_POST['cari'])){if($_POST['bulan']=='4'){echo"selected";}}?> value="4">April</option>
											<option <?php if(isset($_POST['cari'])){if($_POST['bulan']=='5'){echo"selected";}}?> value="5">Mei</option>
											<option <?php if(isset($_POST['cari'])){if($_POST['bulan']=='6'){echo"selected";}}?> value="6">Juni</option>
											<option <?php if(isset($_POST['cari'])){if($_POST['bulan']=='7'){echo"selected";}}?> value="7">Juli</option>
											<option <?php if(isset($_POST['cari'])){if($_POST['bulan']=='8'){echo"selected";}}?> value="8">Agustus</option>
											<option <?php if(isset($_POST['cari'])){if($_POST['bulan']=='9'){echo"selected";}}?> value="9">September</option>
											<option <?php if(isset($_POST['cari'])){if($_POST['bulan']=='10'){echo"selected";}}?> value="10">Oktober</option>
											<option <?php if(isset($_POST['cari'])){if($_POST['bulan']=='11'){echo"selected";}}?> value="11">November</option>
											<option <?php if(isset($_POST['cari'])){if($_POST['bulan']=='12'){echo"selected";}}?> value="12">Desember</option>
										</select>
									</div>
									<div class="form-group">
										<label class="control-label mb-1">Tahun</label>
										<select class="form-control" id="tahun" name="tahun" onchange="pilih()">
											<option selected disabled value="0">--Tahun--</option>
											<?php
												for($i=date('Y'); $i>=date('Y')-5; $i-=1){ ?>
											
												<option <?php if(isset($_POST['cari'])){if($_POST['tahun']==$i){echo "selected";}}?> value=<?php echo $i;?>> <?php echo $i;?> </option>";
												
											<?php }?>
										</select>
									</div>
									
									<div>
										<button type="submit" name="cari" class="btn btn-md btn-success">
											<i class="fa fa-search fa-lg"></i>&nbsp;
											<span id="payment-button-sending">Cari</span>
										</button>
									</div>
								</form>
							</div>
						</div>

					</div>
				</div> <!-- .card -->

			</div>
			<?php }if(isset($_POST['cari'])){?>
			<div class="col-md-12">
			
				<div class="card">
				
					<div class="card-body">
					<div>
					
						<?php 
							if($_POST['bulan']=='1'){
								$bulan="Januari";
							}if($_POST['bulan']=='2'){
								$bulan="Februari";
							}if($_POST['bulan']=='3'){
								$bulan="Maret";
							}if($_POST['bulan']=='4'){
								$bulan="April";
							}if($_POST['bulan']=='5'){
								$bulan="Mei";
							}if($_POST['bulan']=='6'){
								$bulan="Juni";
							}if($_POST['bulan']=='7'){
								$bulan="Juli";
							}if($_POST['bulan']=='8'){
								$bulan="Agustus";
							}if($_POST['bulan']=='9'){
								$bulan="September";
							}if($_POST['bulan']=='10'){
								$bulan="Oktober";
							}if($_POST['bulan']=='11'){
								$bulan="November";
							}if($_POST['bulan']=='12'){
								$bulan="Desember";
							}
							$sub=$tampil['gapok']+$tampil['uang_makan']+$tampil['uang_transport'];
							$pot=$tampil['bpjs_kesehatan']+$tampil['bpjs_ketenagakerjaan'];
							$total=$sub-$pot;
							?>
					</div>
										
					<div class="row">
						<div class="col-md-6">
							<h5>SLIP GAJI</h5>
							<h6>Priode : <?php echo $bulan." - ".$_POST['tahun'];?></h6>
							<p>
								<?php echo $_SESSION['nik']." / ".$_SESSION['nama_lengkap'];?>
							</p>
						</div>
						<div class="col-md-6">
							<h5 align="right">PT TAWAN CEMERLANG ABADI</h5>
							<p style="font-size:12px" align="right">JL. KARYA BARU NO.92 RT.03 RW.01<br>KEC.ALANG-ALANG LEBAR KM7 PALEMBANG</p>
						</div>
						<div class="col-md-12">
							<hr style="margin-top:-16px;border:1px solid black">
							<table style="font-size:14px;margin-top:-10px;margin-bottom:10px">
								<tr>
									<td>Kehadiaran</td>
									<td> : </td>
									<th><?php echo $tampil['ttl_kehadiran']." hari";?></th>
								</tr>
							</table>
						</div>
						<div class="col-md-6" style="margin-left:50px">
							<table style="font-size:14px">
								<tr>
									<td>Gaji Pokok</td>
									<td> : </td>
									<th><?php echo "Rp. ".number_format($tampil['gapok']);?></th>
								</tr>
								<tr>
									<td>Uang Makan</td>
									<td> : </td>
									<th><?php echo "Rp. ".number_format($tampil['uang_makan']);?></th>
								</tr>
								<tr>
									<td>Uang Transport</td>
									<td> : </td>
									<th><?php echo "Rp. ".number_format($tampil['uang_transport']);?></th>
								</tr>
								<tr>
									<td colspan="3"><hr style="border:1px solid black"></td>
								</tr>
								<tr>
									<td></td>
									<td>&nbsp;</td>
									<th><?php echo "Rp. ".number_format($sub);?></th>
								</tr>
							</table>
								
						</div>
						<div class="col-md-6" style="margin-left:-50px">
							<table style="font-size:14px">
								<tr>
									<td>BPJS Kesehatan</td>
									<td> : </td>
									<th><?php echo "( Rp. ".number_format($tampil['bpjs_kesehatan'])." )";?></th>
								</tr>
								<tr>
									<td>BPJS Ketenagakerjaan</td>
									<td> : </td>
									<th><?php echo "( Rp. ".number_format($tampil['bpjs_ketenagakerjaan'])." )";?></th>
								</tr>
								<tr>
									<td colspan="3"><hr style="border:1px solid black"></td>
								</tr>
								<tr>
									<td></td>
									<td>&nbsp;</td>
									<th><?php echo "( Rp. ".number_format($pot)." )";?></th>
								</tr>
							</table>
						</div>
						<div class="col-md-12">
							<hr style="border:1px solid black">
							<h6>Total Gaji : <?php echo "( Rp. ".number_format($total)." )";?></h6>
						</div>
						
					</div>
					
					
					</div>
				</div>
			</div>
			<?php }?>