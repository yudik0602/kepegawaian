<div class="breadcrumbs"><?php include"./ajax/kon.php";?>
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1><?php echo $menu;?></h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo site_url('Welcome');?>">Dashboard</a></li>
					<li class="active"><?php echo $menu;?></li>
				</ol>
			</div>
		</div>
	</div>
</div>

 <div class="content mt-3">

           
            <!--/.col-->

            <div class="col-lg-3 col-md-6">
                <div class="social-box whatsapp">
                    <i class="fa fa-users "></i>
                    <ul>
                        <li>
                            <span style="color:black">Karyawan</span>
                        </li>
                        <li>
                            <span class="count" style="color:black"><?php echo $kar['kar'];?></span>
                        </li>
                    </ul>
                </div>
                <!--/social-box-->
            </div>
            <!--/.col-->


            <div class="col-lg-3 col-md-6">
                <div class="social-box twitter">
                    <i class="fa fa-file"></i>
                    <ul>
                        <li>
                            <span style="color:black">Cuti</span>
                        </li>
                        <li>
                            <span class="count" style="color:black"><?php echo $cut['cut'];?></span>
                        </li>
                    </ul>
                </div>
                <!--/social-box-->
            </div>
            <!--/.col-->


            <div class="col-lg-3 col-md-6">
                <div class="social-box">
                    <i class="fa fa-book"></i>
                    <ul>
                        <li>
                            <span style="color:black">Resign</span>
                        </li>
                        <li>
                            <span class="count" style="color:black"><?php echo $res['res'];?></span>
                        </li>
                    </ul>
                </div>
                <!--/social-box-->
            </div>
            <!--/.col-->


            <div class="col-lg-3 col-md-6">
                <div class="social-box google-plus">
                    <i class="fa fa-address-book"></i>
                    <ul>
                        <li>
                            <span style="color:black">Rekrutment</span>
                        </li>
                        <li>
                            <span class="count" style="color:black"><?php echo $rek['res'];?></span>
                        </li>
                    </ul>
                </div>
                <!--/social-box-->
            </div>
			
			<div class="col-md-12">
               <img src="assets/images/back.png">
            </div>

            
        </div> <!-- .content -->