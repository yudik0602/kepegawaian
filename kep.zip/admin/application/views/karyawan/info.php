<style>
.table-responsive {
	display: block;
	width: 100%;
	overflow-x: auto;
	-webkit-overflow-scrolling: touch;
	-ms-overflow-style: -ms-autohiding-scrollbar; 
}
</style>
<div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1><?php echo $menu;?></h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo site_url('Welcome');?>">Dashboard</a></li>
					<li class="active"><?php echo $menu;?></li>
				</ol>
			</div>
		</div>
	</div>
</div>

<div class="content mt-3">
	<div class="animated fadeIn">

		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header">
						<strong class="card-title">Form <?php echo $menu;?></strong>
					</div>
					<div class="card-body">
						<!-- Credit Card -->
						<div id="pay-invoice">
							<div class="card-body">
								
								<div class="row">
								<div class="col-md-4">
                                    <div class="invoice-cmp-ds ivc-to">
										<table>
											<tr>
												<td>NIK</td>
												<td> : </td>
												<td><?php echo $tampil['nik'];?></td>
											</tr>
											<tr>
												<td>NO KTP</td>
												<td> : </td>
												<td><?php echo $tampil['no_ktp'];?></td>
											</tr>
											<tr>
												<td>Nama Lengkap</td>
												<td> : </td>
												<td><?php echo $tampil['nama'];?></td>
											</tr>
											<tr>
												<td>Jabatan</td>
												<td> : </td>
												<td><?php echo $tampil['jabatan'];?></td>
											</tr>
											<tr>
												<td>No Hp</td>
												<td> : </td>
												<td><?php echo $tampil['no_hp'];?></td>
											</tr>
											<tr>
												<td>Alamat</td>
												<td> : </td>
												<td><?php echo $tampil['alamat'];?></td>
											</tr>
											<tr>
												<td>Email</td>
												<td> : </td>
												<td><?php echo $tampil['email'];?></td>
											</tr>
											<tr>
												<td>Status</td>
												<td> : </td>
												<td><?php echo $tampil['status'];?></td>
											</tr>
											<tr>
												<td>Tempat Lahir</td>
												<td> : </td>
												<td><?php echo $tampil['tempat_lahir'];?></td>
											</tr>
											<tr>
												<td>Tgl Lahir</td>
												<td> : </td>
												<td><?php echo $tampil['tgl_lahir'];?></td>
											</tr>
											<tr>
												<td>Jenis Kelamin</td>
												<td> : </td>
												<td><?php echo $tampil['jenis_kelamin'];?></td>
											</tr>
											<tr>
												<td>Agama</td>
												<td> : </td>
												<td><?php echo $tampil['agama'];?></td>
											</tr>
											<tr>
												<td>Gol. Darah</td>
												<td> : </td>
												<td><?php echo $tampil['gol_darah'];?></td>
											</tr>
											<tr>
												<td>Pendidikan</td>
												<td> : </td>
												<td><?php echo $tampil['pendidikan'];?></td>
											</tr>
											
											<tr>
												<td>Gaji Pokok</td>
												<td> : </td>
												<td><?php echo $tampil['gaji_pokok'];?></td>
											</tr>
											<tr>
												<td>Uang Makan</td>
												<td> : </td>
												<td><?php echo $tampil['uang_makan'];?></td>
											</tr>
											<tr>
												<td>Uang Transport</td>
												<td> : </td>
												<td><?php echo $tampil['uang_transport'];?></td>
											</tr>
											<tr>
												<td>BPJS Kesehatan</td>
												<td> : </td>
												<td><?php echo $tampil['bpjs_kesehatan'];?></td>
											</tr>
											<tr>
												<td>BPJS Ketenagakerjaan</td>
												<td> : </td>
												<td><?php echo $tampil['bpjs_ketenagakerjaan'];?></td>
											</tr>
											<tr>
												<td>Tgl Masuk Kerja</td>
												<td> : </td>
												<td><?php echo $tampil['tgl_masuk'];?></td>
											</tr>
											<tr>
												<td>Status Kerja</td>
												<td> : </td>
												<td><?php echo $tampil['status_kerja'];?></td>
											</tr>
											<tr>
												<td>Foto</td>
												<td> : </td>
												<td><a target="_blank" href="<?php echo site_url('./assets/images/foto/'.$tampil['foto']);?>"><?php echo $tampil['foto'];?></a></td>
											</tr><tr>
												<td>KTP</td>
												<td> : </td>
												<td><a target="_blank" href="<?php echo site_url('./assets/images/lam_ktp/'.$tampil['lam_ktp']);?>"><?php echo $tampil['lam_ktp'];?></a></td>
											</tr><tr>
												<td>KK</td>
												<td> : </td>
												<td><a target="_blank" href="<?php echo site_url('./assets/images/lam_kk/'.$tampil['lam_kk']);?>"><?php echo $tampil['lam_kk'];?></a></td>
											</tr><tr>
												<td>Ijazah</td>
												<td> : </td>
												<td><a target="_blank" href="<?php echo site_url('./assets/images/lam_ijazah/'.$tampil['lam_ijazah']);?>"><?php echo $tampil['lam_ijazah'];?></a></td>
											</tr>
										</table>
										
                                    </div>
                                </div>                               
                            </div>
						</div>

					</div>
				</div> <!-- .card -->

			</div>
			</div>
			<!--/.col--
	