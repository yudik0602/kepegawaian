<style>
.table-responsive {
	display: block;
	width: 100%;
	overflow-x: auto;
	-webkit-overflow-scrolling: touch;
	-ms-overflow-style: -ms-autohiding-scrollbar; 
}
</style>
<div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1><?php echo $menu;?></h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo site_url('Welcome');?>">Dashboard</a></li>
					<li class="active"><?php echo $menu;?></li>
				</ol>
			</div>
		</div>
	</div>
</div>

<div class="content mt-3">
	<div class="animated fadeIn">

		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-header">
						<strong class="card-title">Form <?php echo $menu;?></strong>
					</div>
					<div class="card-body">
						<!-- Credit Card -->
						<div id="pay-invoice">
							<div class="card-body">
								<form action="<?php echo $url;?>" method="post" enctype="multipart/form-data">
								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label mb-1">NIK</label>
											<input name="nik" type="text" class="form-control" required <?php if($aksi=="ubah"){echo 'value="'.$cd['nik'].'"';}?>>
										</div>
										<div class="form-group">
											<label class="control-label mb-1">NO KTP</label>
											<input name="no_ktp" type="text" class="form-control" required <?php if($aksi=="ubah"){echo 'value="'.$cd['no_ktp'].'"';}?>>
										</div>
										<div class="form-group">
											<label class="control-label mb-1">Nama Lengkap</label>
											<input name="nama" type="text" class="form-control" required <?php if($aksi=="ubah"){echo 'value="'.$cd['nama'].'"';}?>>
										</div>
										<div class="form-group">
											<label class="control-label mb-1">Nomor HP</label>
											<input name="no_hp" type="number" class="form-control" required <?php if($aksi=="ubah"){echo 'value="'.$cd['no_hp'].'"';}?>>
										</div>
										<div class="form-group">
											<label class="control-label mb-1">Alamat</label>
											<textarea name="alamat" rows="4" class="form-control" required><?php if($aksi=="ubah"){echo $cd['alamat'];}?></textarea>
										</div>
										<div class="form-group">
											<label class="control-label mb-1">Email</label>
											<input name="email" type="email" class="form-control" required <?php if($aksi=="ubah"){echo 'value="'.$cd['email'].'"';}?>>
										</div>
										<div class="form-group">
											<label for="cc-number" class="control-label mb-1">Status</label>
											<select name="status" class="form-control">
												<option <?php if($aksi=="ubah"){if($cd['status']=="Kawin"){echo "selected";}}?>>Kawin</option>
												<option <?php if($aksi=="ubah"){if($cd['status']=="Belum Kawin"){echo "selected";}}?>>Belum Kawin</option>
											</select>
										</div>
										<div class="form-group">
											<label class="control-label mb-1">Tempat Lahir</label>
											<textarea name="tempat_lahir" rows="4" class="form-control" required><?php if($aksi=="ubah"){echo $cd['tempat_lahir'];}?></textarea>
										</div>
										
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label mb-1">Tgl Lahir</label>
											<input name="tgl_lahir" type="date" class="form-control" required <?php if($aksi=="ubah"){echo 'value="'.$cd['tgl_lahir'].'"';}?>>
										</div>
										<div class="form-group">
											<label for="cc-number" class="control-label mb-1">Jenis Kelamin</label>
											<select name="jenis_kelamin" class="form-control">
												<option <?php if($aksi=="ubah"){if($cd['jenis_kelamin']=="Laki-Laki"){echo "selected";}}?>>Laki-Laki</option>
												<option <?php if($aksi=="ubah"){if($cd['jenis_kelamin']=="Perempuan"){echo "selected";}}?>>Perempuan</option>
											</select>
										</div>
										<div class="form-group">
											<label for="cc-number" class="control-label mb-1">Agama</label>
											<select name="agama" class="form-control">
												<option value="" disabled selected>-- Pilih --</option>
												<option <?php if($aksi=="ubah"){if($cd['agama']=="Islam"){echo "selected";}}?>>Islam</option>
												<option <?php if($aksi=="ubah"){if($cd['agama']=="Katolik"){echo "selected";}}?>>Katolik</option>
												<option <?php if($aksi=="ubah"){if($cd['agama']=="Kristen"){echo "selected";}}?>>Kristen</option>
												<option <?php if($aksi=="ubah"){if($cd['agama']=="Hindu"){echo "selected";}}?>>Hindu</option>
												<option <?php if($aksi=="ubah"){if($cd['agama']=="Buddha"){echo "selected";}}?>>Buddha</option>
												<option <?php if($aksi=="ubah"){if($cd['agama']=="Konghucu"){echo "selected";}}?>>Konghucu</option>
											</select>
										</div>
										<div class="form-group">
											<label for="cc-number" class="control-label mb-1">Gol Darah</label>
											<select name="gol_darah" class="form-control">
												<option value="" disabled selected>-- Pilih --</option>
												<option <?php if($aksi=="ubah"){if($cd['gol_darah']=="A"){echo "selected";}}?>>A</option>
												<option <?php if($aksi=="ubah"){if($cd['gol_darah']=="B"){echo "selected";}}?>>B</option>
												<option <?php if($aksi=="ubah"){if($cd['gol_darah']=="O"){echo "selected";}}?>>O</option>
												<option <?php if($aksi=="ubah"){if($cd['gol_darah']=="AB"){echo "selected";}}?>>AB</option>
											</select>
										</div>
										<div class="form-group">
											<label for="cc-number" class="control-label mb-1">Pendidikan</label>
											<select name="pendidikan" class="form-control">
												<option value="" disabled selected>-- Pilih --</option>
												<option <?php if($aksi=="ubah"){if($cd['pendidikan']=="SMA SEDERAJAT"){echo "selected";}}?>>SMA SEDERAJAT</option>
												<option <?php if($aksi=="ubah"){if($cd['pendidikan']=="D1"){echo "selected";}}?>>D1</option>
												<option <?php if($aksi=="ubah"){if($cd['pendidikan']=="D3"){echo "selected";}}?>>D3</option>
												<option <?php if($aksi=="ubah"){if($cd['pendidikan']=="D4"){echo "selected";}}?>>D4</option>
												<option <?php if($aksi=="ubah"){if($cd['pendidikan']=="S1"){echo "selected";}}?>>S1</option>
												<option <?php if($aksi=="ubah"){if($cd['pendidikan']=="S2"){echo "selected";}}?>>S2</option>
												<option <?php if($aksi=="ubah"){if($cd['pendidikan']=="S3"){echo "selected";}}?>>S3</option>
											</select>
										</div>
										<div class="form-group">
											<label class="control-label mb-1">Jabatan</label>
											<input name="jabatan" type="text" class="form-control" required <?php if($aksi=="ubah"){echo 'value="'.$cd['jabatan'].'"';}?>>
										</div>
										<div class="form-group">
											<label class="control-label mb-1">Foto</label>
											<input name="foto" type="file" class="form-control" required>
										</div>
										<div class="form-group">
											<label class="control-label mb-1">Ijazah</label>
											<input name="lam_ijazah" type="file" class="form-control" required>
										</div>
										<div class="form-group">
											<label class="control-label mb-1">Kartu Keluarga</label>
											<input name="lam_kk" type="file" class="form-control" required>
										</div>
									
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="control-label mb-1">KTP</label>
											<input name="lam_ktp" type="file" class="form-control" required>
										</div>
										<div class="form-group">
											<label class="control-label mb-1">Gaji Pokok</label>
											<input name="gaji_pokok" type="number" class="form-control" required <?php if($aksi=="ubah"){echo 'value="'.$cd['gaji_pokok'].'"';}?>>
										</div>
										<div class="form-group">
											<label class="control-label mb-1">Uang Makan</label>
											<input name="uang_makan" type="number" class="form-control" required <?php if($aksi=="ubah"){echo 'value="'.$cd['uang_makan'].'"';}?>>
										</div>
										<div class="form-group">
											<label class="control-label mb-1">Uang Transport</label>
											<input name="uang_transport" type="number" class="form-control" required <?php if($aksi=="ubah"){echo 'value="'.$cd['uang_transport'].'"';}?>>
										</div>
										<div class="form-group">
											<label class="control-label mb-1">BPJS Kesehatan</label>
											<input name="bpjs_kesehatan" type="number" class="form-control" required <?php if($aksi=="ubah"){echo 'value="'.$cd['bpjs_kesehatan'].'"';}?>>
										</div>
										<div class="form-group">
											<label class="control-label mb-1">BPJS Ketenagakerjaan</label>
											<input name="bpjs_ketenagakerjaan" type="number" class="form-control" required <?php if($aksi=="ubah"){echo 'value="'.$cd['bpjs_ketenagakerjaan'].'"';}?>>
										</div>
										<div class="form-group">
											<label class="control-label mb-1">Tanggal Masuk Kerja</label>
											<input name="tgl_masuk" type="date" class="form-control" required <?php if($aksi=="ubah"){echo 'value="'.$cd['tgl_masuk'].'"';}?>>
										</div>
										<div class="form-group">
											<button type="submit" class="btn btn-md btn-success">
												<i class="fa fa-save fa-lg"></i>&nbsp;
												<span id="payment-button-sending">Simpan</span>
											</button>
											<button type="reset" class="btn btn-md btn-danger" onclick="document.location='<?php echo site_url('Pelanggan');?>'">
												<i class="fa fa-refresh fa-lg"></i>&nbsp;
												<span id="payment-button-sending">Batal</span>
											</button>
										</div>
									</div>
								</form>
							</div>
						</div>

					</div>
				</div> <!-- .card -->

			</div>
			</div>
			<!--/.col-->

			<div class="col-md-12">
				<div class="card">
					<div class="card-header"><strong>Tabel <?php echo $menu;?></strong></div>
					<div class="card-body">
					<div class="table-responsive">
						 <table id="bootstrap-data-table-export" class="table table-striped table-bordered" style="font-size:12px;">
							<thead>
								<tr>
									<th width="20%">Aksi</th>
									<th width="5%">No</th>
									<th width="15%">NIK</th>
									<th width="19%">Nama</th>
									<th width="23%">Alamat</th>
									<th width="15%">No Tlpn</th>
									<th width="15%">Mulai Kerja</th>
								</tr>
							</thead>
							<tbody>
							 <?php
								$i=1;
								foreach($tampil->result_array() as $res){
							  ?>
								<tr>
									<td><a href="<?php echo site_url('karyawan/index/ubah/'.$res['nik'])?>" class="btn btn-sm btn-warning"><i class="menu-icon fa fa-edit"></i></a> <a href="<?php echo site_url('karyawan/hapus/'.$res['nik'])?>" class="btn btn-sm btn-danger"><i class="menu-icon fa fa-close"></i></a>
									<a href="<?php echo site_url('karyawan/info/'.$res['nik'])?>" class="btn btn-sm btn-info">DETAIL</a></td>
									<td><?php echo $i++;?></td>
									<td><?php echo $res['nik'];?></td>
									<td><?php echo $res['nama'];?></td>
									<td><?php echo $res['alamat'];?></td>
									<td><?php echo $res['no_hp'];?></td>
									<td><?php echo $res['tgl_masuk'];?></td>
								</tr>
								<?php }?>
							</tbody>
						</table>
					</div>
					</div>
				</div>
			</div>
	