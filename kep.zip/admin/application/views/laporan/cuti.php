<style>
.table-responsive {
	display: block;
	width: 100%;
	overflow-x: auto;
	-webkit-overflow-scrolling: touch;
	-ms-overflow-style: -ms-autohiding-scrollbar; 
}
</style>
<div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1><?php echo $menu;?></h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo site_url('Welcome');?>">Dashboard</a></li>
					<li class="active"><?php echo $menu;?></li>
				</ol>
			</div>
		</div>
	</div>
</div>

<div class="content mt-3">
	<div class="animated fadeIn">

		<div class="row">
		<?php if(!isset($_POST['cari'])){?>
			<div class="col-lg-7">
				<div class="card">
					<div class="card-header bg-success">
						<strong class="card-title" style="color:white">Pilih Priode Laporan</strong>
					</div>
					<div class="card-body">
						<!-- Credit Card -->
						<div id="pay-invoice">
							<div class="card-body">
								<form method="post" enctype="multipart/form-data">
									<div class="form-group">
										<label class="control-label mb-1">Dari Tanggal</label>
										<input name="dari_tgl" id="dari_tgl" type="date" class="form-control" required>
									</div>
									<div class="form-group">
										<label class="control-label mb-1">Sampai Tanggal</label>
										<input name="sampai_tgl" id="sampai_tgl" type="date" class="form-control" required >
									</div>
									<div class="form-group">
										<label for="cc-number" class="control-label mb-1">Karyawan</label>
										<select class="form-control" name="nik" id="nik" required>
											<option value="all" selected>-- SEMUA --</option>
											<?php
												foreach($nik->result_array() as $ops){
											?>
												<option value="<?php echo $ops['nik'];?>"><?php echo $ops['nik']." - ".$ops['nama'];?></option>
											<?php }?>
										</select>
									</div>
									<div>
										<button type="submit" name="cari" class="btn btn-md btn-success">
											<i class="fa fa-search fa-lg"></i>&nbsp;
											<span id="payment-button-sending">Cari</span>
										</button>
									</div>
								</form>
							</div>
						</div>

					</div>
				</div> <!-- .card -->

			</div>
			<?php }if(isset($_POST['cari'])){?>
			<div class="col-md-12">
			
				<div class="card">
				
					<div class="card-body">
					<div>
						<h3>PT TAWAN CEMERLANG ABADI</h3>
						<h5>LAPORAN DATA CUTI</h5>
						<p>PERIODE LAPORAN : <?php if(isset($_POST['cari'])){echo $_POST['dari_tgl']." s/d ".$_POST['sampai_tgl'];}?></p>
					</div>
					<div class="table-responsive">
						 <table class="table table-striped table-bordered table-hover" style="font-size:12px;">
							<thead>
								<tr>
									<th width="5%">No</th>
									<th width="15%">NIK</th>
									<th width="15%">Nama</th>
									<th width="10%">Kategori</th>
									<th width="15%">Keterangan</th>
									<th width="15%">Periode Cuti</th>
									<th width="10%">Lama</th>
									<th width="10%">Status</th>
									<th width="10%">Alasan</th>
								</tr>
							</thead>
							
							<tbody>
							 <?php
								$i=1;
								foreach($tampil->result_array() as $res){
							  ?>
								<tr>
									<td><?php echo $i++;?></td>
									<td><?php echo $res['nik'];?></td>
									<td><?php echo $res['nama'];?></td>
									<td><?php echo $res['kategori_cuti'];?></td>
									<td><?php echo $res['keterangan'];?></td>
									<td><?php echo $res['dari_tgl']." s/d ".$res['sampai_tgl'];?></td>
									<td><?php echo $res['lama_cuti']." hari";?></td>
									<td><?php echo $res['status_cuti'];?></td>
									<td><?php echo $res['ket_val'];?></td>
								</tr>
								<?php }?>
							</tbody>
							
						</table>
					</div>
					 <?php if($_POST['nik']!='all'){?>
					 <a class="form-control btn btn-info" target="_blank" href="<?php echo site_url("Cetak/cuti?awal=$_POST[dari_tgl]&akhir=$_POST[sampai_tgl]&nik=$_POST[nik]");?>">CETAK</a>
					 <?php }else{?>
					 <a class="form-control btn btn-info" target="_blank" href="<?php echo site_url("Cetak/cuti?awal=$_POST[dari_tgl]&akhir=$_POST[sampai_tgl]");?>">CETAK</a>
					 <?php }?>
					</div>
				</div>
			</div>
			<?php }?>