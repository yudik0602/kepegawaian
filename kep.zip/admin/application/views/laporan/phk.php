<style>
.table-responsive {
	display: block;
	width: 100%;
	overflow-x: auto;
	-webkit-overflow-scrolling: touch;
	-ms-overflow-style: -ms-autohiding-scrollbar; 
}
</style>
<div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1><?php echo $menu;?></h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo site_url('Welcome');?>">Dashboard</a></li>
					<li class="active"><?php echo $menu;?></li>
				</ol>
			</div>
		</div>
	</div>
</div>

<div class="content mt-3">
	<div class="animated fadeIn">

		<div class="row">
		<?php if(!isset($_POST['cari'])){?>
			<div class="col-lg-7">
				<div class="card">
					<div class="card-header bg-success">
						<strong class="card-title" style="color:white">Pilih Priode Laporan</strong>
					</div>
					<div class="card-body">
						<!-- Credit Card -->
						<div id="pay-invoice">
							<div class="card-body">
								<form method="post" enctype="multipart/form-data">
									<div class="form-group">
										<label class="control-label mb-1">Dari Tanggal</label>
										<input name="dari_tgl" id="dari_tgl" type="date" class="form-control" required>
									</div>
									<div class="form-group">
										<label class="control-label mb-1">Sampai Tanggal</label>
										<input name="sampai_tgl" id="sampai_tgl" type="date" class="form-control" required >
									</div>
									
									<div>
										<button type="submit" name="cari" class="btn btn-md btn-success">
											<i class="fa fa-search fa-lg"></i>&nbsp;
											<span id="payment-button-sending">Cari</span>
										</button>
									</div>
								</form>
							</div>
						</div>

					</div>
				</div> <!-- .card -->

			</div>
			<?php }if(isset($_POST['cari'])){?>
			<div class="col-md-12">
			
				<div class="card">
				
					<div class="card-body">
					<div>
						<h3>PT TAWAN CEMERLANG ABADI</h3>
						<h5>LAPORAN DATA PHK</h5>
						<p>PERIODE LAPORAN : <?php if(isset($_POST['cari'])){echo $_POST['dari_tgl']." s/d ".$_POST['sampai_tgl'];}?></p>
					</div>
					<div class="table-responsive">
						 <table class="table table-striped table-bordered table-hover" style="font-size:12px;">
							<thead>
								<tr>
									<th width="5%">No</th>
									<th width="10%">NIK</th>
									<th width="15%">Nama</th>
									<th width="15%">Keterangan</th>
									<th width="15%">Lampiran</th>
									<th width="15%">Status</th>
									<th width="10%">Tgl Phk</th>
								</tr>
							</thead>
							<tbody>
							 <?php
								$i=1;
								foreach($tampil->result_array() as $res){
							  ?>
								<tr>
									<td><?php echo $i++;?></td>
									<td><?php echo $res['nik'];?></td>
									<td><?php echo $res['nama'];?></td>
									<td><?php echo $res['keterangan_phk'];?></td>
									<td><a target="_blank" href="<?php echo config_item('images')?>/lam_phk/<?php echo $res['lampiran'];?>"><?php echo $res['lampiran'];?></a></td>
									<td><?php echo $res['status_phk'];?></td>
									<td><?php echo $res['tgl_phk'];?></td>
								</tr>
								<?php }?>
							</tbody>
						</table>
					</div>
					 <a class="form-control btn btn-info" target="_blank" href="<?php echo site_url("Cetak/phk?awal=$_POST[dari_tgl]&akhir=$_POST[sampai_tgl]");?>">CETAK</a>
					</div>
				</div>
			</div>
			<?php }?>