<style>
.table-responsive {
	display: block;
	width: 100%;
	overflow-x: auto;
	-webkit-overflow-scrolling: touch;
	-ms-overflow-style: -ms-autohiding-scrollbar; 
}
</style>
<div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1><?php echo $menu;?></h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo site_url('Welcome');?>">Dashboard</a></li>
					<li class="active"><?php echo $menu;?></li>
				</ol>
			</div>
		</div>
	</div>
</div>

<div class="content mt-3">
	<div class="animated fadeIn">

		<div class="row">
			<div class="col-lg-4">
				<div class="card">
					<div class="card-header">
						<strong class="card-title">Form <?php echo $menu;?></strong>
					</div>
					<div class="card-body">
						<!-- Credit Card -->
						<div id="pay-invoice">
							<div class="card-body">
								<form action="<?php echo $url;?>" method="post" enctype="multipart/form-data">
									<div class="form-group">
										<label for="cc-number" class="control-label mb-1">NIK</label>
										<select class="form-control" name="nik" id="nik" required>
											<option value="" disabled selected>-- Pilih --</option>
											<?php
												foreach($karyawan->result_array() as $ops){
											?>
												<option <?php if($aksi=="ubah"){if($cd['nik']==$ops['nik']){echo "selected=''";}}?> value="<?php echo $ops['nik'];?>"><?php echo $ops['nik']." - ".$ops['nama'];?></option>
											<?php }?>
										</select>
									</div>
									<div class="form-group">
										<label for="cc-number" class="control-label mb-1">Akses</label>
										<select name="akses" class="form-control">
											<option <?php if($aksi=="ubah"){if($cd['akses']=="Manager HRD"){echo "selected";}}?>>Manager HRD</option>
											<option <?php if($aksi=="ubah"){if($cd['akses']=="HRD"){echo "selected";}}?>>HRD</option>
											<option <?php if($aksi=="ubah"){if($cd['akses']=="Karyawan"){echo "selected";}}?>>Karyawan</option>
										</select>
									</div>
									<div class="form-group">
										<label for="cc-number" class="control-label mb-1">Password</label>
										<input name="password" type="password" class="form-control" required>
									</div>
									<div>
										<button type="submit" class="btn btn-md btn-success">
											<i class="fa fa-save fa-lg"></i>&nbsp;
											<span id="payment-button-sending">Simpan</span>
										</button>
										<button type="reset" class="btn btn-md btn-danger" onclick="document.location='<?php echo site_url('Pengguna');?>'">
											<i class="fa fa-refresh fa-lg"></i>&nbsp;
											<span id="payment-button-sending">Batal</span>
										</button>
									</div>
								</form>
							</div>
						</div>

					</div>
				</div> <!-- .card -->

			</div>
			<!--/.col-->

			<div class="col-lg-8">
				<div class="card">
					<div class="card-header"><strong>Tabel <?php echo $menu;?></strong></div>
					<div class="card-body">
					<div class="table-responsive">
						 <table id="bootstrap-data-table-export" class="table table-striped table-bordered" style="font-size:12px;">
							<thead>
								<tr>
									<th width="20%">Aksi</th>
									<th width="5%">No</th>
									<th width="25%">Akses</th>
									<th width="15%">NIK</th>
								</tr>
							</thead>
							<tbody>
							 <?php
								$i=1;
								foreach($tampil->result_array() as $res){
							  ?>
								<tr>
									<td><a href="<?php echo site_url('Pengguna/index/ubah/'.$res['nik'])?>" class="btn btn-sm btn-warning"><i class="menu-icon fa fa-edit"></i></a> <a href="<?php echo site_url('Pengguna/hapus/'.$res['nik'])?>" class="btn btn-sm btn-danger"><i class="menu-icon fa fa-close"></i></a></td>
									<td><?php echo $i++;?></td>
									<td><?php echo $res['nik'];?></td>
									<td><?php echo $res['akses'];?></td>
								</tr>
								<?php }?>
							</tbody>
						</table>
					</div>
					</div>
				</div>
			</div>
	