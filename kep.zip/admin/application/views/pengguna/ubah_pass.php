<style>
.table-responsive {
	display: block;
	width: 100%;
	overflow-x: auto;
	-webkit-overflow-scrolling: touch;
	-ms-overflow-style: -ms-autohiding-scrollbar; 
}
</style>
<div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1><?php echo $menu;?></h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo site_url('Welcome');?>">Dashboard</a></li>
					<li class="active"><?php echo $menu;?></li>
				</ol>
			</div>
		</div>
	</div>
</div>

<div class="content mt-3">
	<div class="animated fadeIn">

		<div class="row">
			<div class="col-lg-4">
				<div class="card">
					<div class="card-header">
						<strong class="card-title">Form <?php echo $menu;?></strong>
					</div>
					<div class="card-body">
						<!-- Credit Card -->
						<div id="pay-invoice">
							<div class="card-body">
								<form action="<?php echo $url;?>" method="post" novalidate="novalidate" enctype="multipart/form-data">
									<div class="form-group">
										<label for="cc-number" class="control-label mb-1">Password Lama</label>
										<input name="pass_lama" type="password" class="form-control" required placeholder="**********">
									</div>
									<div class="form-group">
										<label for="cc-number" class="control-label mb-1">Password Baru</label>
										<input name="pass_baru" type="password" class="form-control" required placeholder="**********">
									</div>
									<div class="form-group">
										<label for="cc-number" class="control-label mb-1">Konfirmasi Password</label>
										<input name="kon_pass" type="password" class="form-control" required placeholder="**********">
									</div>
									<div>
										<button type="submit" class="btn btn-md btn-success">
											<i class="fa fa-save fa-lg"></i>&nbsp;
											<span id="payment-button-sending">Simpan</span>
										</button>
										<button type="reset" class="btn btn-md btn-danger" onclick="document.location='<?php echo site_url('Ubahpass');?>'">
											<i class="fa fa-refresh fa-lg"></i>&nbsp;
											<span id="payment-button-sending">Batal</span>
										</button>
									</div>
								</form>
							</div>
						</div>

					</div>
				</div> <!-- .card -->

			</div>
			<!--/.col-->
	