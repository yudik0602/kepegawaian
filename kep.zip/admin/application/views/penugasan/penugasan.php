<style>
.table-responsive {
	display: block;
	width: 100%;
	overflow-x: auto;
	-webkit-overflow-scrolling: touch;
	-ms-overflow-style: -ms-autohiding-scrollbar; 
}
</style>
<div class="breadcrumbs">
	<div class="col-sm-4">
		<div class="page-header float-left">
			<div class="page-title">
				<h1><?php echo $menu;?></h1>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
		<div class="page-header float-right">
			<div class="page-title">
				<ol class="breadcrumb text-right">
					<li><a href="<?php echo site_url('Welcome');?>">Dashboard</a></li>
					<li class="active"><?php echo $menu;?></li>
				</ol>
			</div>
		</div>
	</div>
</div>

<div class="content mt-3">
	<div class="animated fadeIn">

		<div class="row">
			<div class="col-lg-7">
				<div class="card">
					<div class="card-header">
						<strong class="card-title">Form <?php echo $menu;?></strong>
					</div>
					<div class="card-body">
						<!-- Credit Card -->
						<div id="pay-invoice">
							<div class="card-body">
								<form action="<?php echo $url;?>" method="post" enctype="multipart/form-data">
									<div class="form-group">
										<label for="cc-number" class="control-label mb-1">NIK</label>
										<select class="form-control" name="nik" id="nik" required>
											<option value="" disabled selected>-- Pilih --</option>
											<?php
												foreach($nik->result_array() as $ops){
											?>
												<option <?php if($aksi=="ubah"){if($cd['nik']==$ops['nik']){echo "selected=''";}}?> value="<?php echo $ops['nik'];?>"><?php echo $ops['nik']." - ".$ops['nama'];?></option>
											<?php }?>
										</select>
									</div>
									<div class="form-group">
										<label for="cc-number" class="control-label mb-1">Keterangan Penugasan</label>
										<textarea class="form-control" rows="6" required name="keterangan"><?php if($aksi=="ubah"){echo $cd['keterangan'];}?></textarea>
									</div>
									<div class="form-group">
										<label class="control-label mb-1">Dari Tanggal</label>
										<input name="dari_tgl" type="date" class="form-control" required <?php if($aksi=="ubah"){echo 'value="'.$cd['dari_tgl'].'"';}?>>
									</div>
									<div class="form-group">
										<label class="control-label mb-1">Sampai Tanggal</label>
										<input name="sampai_tgl" type="date" class="form-control" required <?php if($aksi=="ubah"){echo 'value="'.$cd['sampai_tgl'].'"';}?>>
									</div>
									<div>
										<button type="submit" class="btn btn-md btn-success">
											<i class="fa fa-save fa-lg"></i>&nbsp;
											<span id="payment-button-sending">Simpan</span>
										</button>
										<button type="reset" class="btn btn-md btn-danger" onclick="document.location='<?php echo site_url('Pengguna');?>'">
											<i class="fa fa-refresh fa-lg"></i>&nbsp;
											<span id="payment-button-sending">Batal</span>
										</button>
									</div>
								</form>
							</div>
						</div>

					</div>
				</div> <!-- .card -->

			</div>
			<!--/.col-->

			<div class="col-md-5">
				<div class="card">
					<div class="card-header"><strong>INFO KARYAWAN</strong></div>
					<div class="card-body">
					<div class="table-responsive">
						 <table class="table" style="font-size:12px;">
							<tr>
								<th>Foto</th>
								<th> : </th>
								<th><div id="foto"></div><?php if($aksi=="ubah"){echo "<img src='".config_item('images')."/foto/".$kar['foto']."' width='150px'>";} ?></th>
							</tr>
							<tr>
								<th>NIK</th>
								<th> : </th>
								<th><div id="niks"><?php if($aksi=="ubah"){echo $kar['nik'];} ?></div></th>
							</tr>
							<tr>
								<th>Nama</th>
								<th> : </th>
								<th><div id="nama"><?php if($aksi=="ubah"){echo $kar['nama'];} ?></div></th>
							</tr>
							<tr>
								<th>Jabatan</th>
								<th> : </th>
								<th><div id="jabatan"><?php if($aksi=="ubah"){echo $kar['jabatan'];} ?></div></th>
							</tr>
							<tr>
								<th>No HP</th>
								<th> : </th>
								<th><div id="no_hp"><?php if($aksi=="ubah"){echo $kar['no_hp'];} ?></div></th>
							</tr>
							<tr>
								<th>Email</th>
								<th> : </th>
								<th><div id="email"><?php if($aksi=="ubah"){echo $kar['email'];} ?></div></th>
							</tr>
						</table>
					</div>
					</div>
				</div>
			</div>
			<div class="col-md-12">
				<div class="card">
					<div class="card-header"><strong>Tabel <?php echo $menu;?></strong></div>
					<div class="card-body">
					<div class="table-responsive">
						 <table id="bootstrap-data-table-export" class="table table-striped table-bordered" style="font-size:12px;">
							<thead>
								<tr>
									<th width="20%">Aksi</th>
									<th width="5%">No</th>
									<th width="25%">NIK</th>
									<th width="15%">Nama</th>
									<th width="15%">Keterangan</th>
									<th width="15%">Periode Tugas</th>
									<th width="15%">Status</th>
								</tr>
							</thead>
							<tbody>
							 <?php
								$i=1;
								foreach($tampil->result_array() as $res){
							  ?>
								<tr>
									<td><a href="<?php echo site_url('Penugasan/index/ubah/'.$res['id_penugasan'])?>" class="btn btn-sm btn-warning"><i class="menu-icon fa fa-edit"></i></a> <a href="<?php echo site_url('Penugasan/hapus/'.$res['id_penugasan'])?>" class="btn btn-sm btn-danger"><i class="menu-icon fa fa-close"></i></a></td>
									<td><?php echo $i++;?></td>
									<td><?php echo $res['nik'];?></td>
									<td><?php echo $res['nama'];?></td>
									<td><?php echo $res['keterangan'];?></td>
									<td><?php echo $res['dari_tgl']." s/d ".$res['sampai_tgl'];?></td>
									<td><?php echo $res['status_penugasan'];?></td>
								</tr>
								<?php }?>
							</tbody>
						</table>
					</div>
					</div>
				</div>
			</div>
	<script>
		$(document).ready(function(){
			document.getElementById('nik').focus();
			$('#nik').change(function(){
				if($(this).val() !== '')
				{
					$.ajax({
						url: "ajax/karyawan.php",
						type: "POST",
						cache: false,
						data: "nik="+$(this).val(),
						dataType:'json',
						success: function(json){
							$('#niks').html(json.nik);
							$('#nama').html(json.nama);
							$('#no_hp').html(json.no_hp);
							$('#email').html(json.email);
							$('#jabatan').html(json.jabatan);
							$('#foto').html(json.foto);
						}
					});
				}
				else
				{
					$('#niks').html('<small><i>Tidak ada</i></small>');
					$('#nama').html('<small><i>Tidak ada</i></small>');
					$('#no_hp').html('<small><i>Tidak ada</i></small>');
					$('#email').html('<small><i>Tidak ada</i></small>');
					$('#jabatan').html('<small><i>Tidak ada</i></small>');
					$('#foto').html('<small><i>Tidak ada</i></small>');
				}
			});
			
		});
	</script>