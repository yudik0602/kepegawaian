-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.36-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             12.4.0.6659
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table kep.tb_absen
CREATE TABLE IF NOT EXISTS `tb_absen` (
  `id_absen` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `masuk` time NOT NULL,
  `pulang` time NOT NULL,
  `status_kehadiran` varchar(1) NOT NULL,
  `foto` text NOT NULL,
  `langli` text NOT NULL,
  `longli` text NOT NULL,
  PRIMARY KEY (`id_absen`) USING BTREE,
  KEY `nip` (`nik`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table kep.tb_absen: ~1 rows (approximately)
INSERT INTO `tb_absen` (`id_absen`, `nik`, `tanggal`, `masuk`, `pulang`, `status_kehadiran`, `foto`, `langli`, `longli`) VALUES
	(0, '20230001', '2023-12-19', '18:03:56', '19:42:45', 'T', '6581789c459bf.png', '-4.2795008', '105.2049408');

-- Dumping structure for table kep.tb_cuti
CREATE TABLE IF NOT EXISTS `tb_cuti` (
  `id_cuti` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(20) NOT NULL,
  `kategori_cuti` varchar(50) NOT NULL DEFAULT '',
  `dari_tgl` date NOT NULL,
  `sampai_tgl` date NOT NULL,
  `lama_cuti` int(11) NOT NULL,
  `keterangan` text NOT NULL,
  `status_cuti` varchar(30) NOT NULL,
  `tgl_simpan` date NOT NULL,
  PRIMARY KEY (`id_cuti`),
  KEY `nip` (`nik`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table kep.tb_cuti: ~1 rows (approximately)
INSERT INTO `tb_cuti` (`id_cuti`, `nik`, `kategori_cuti`, `dari_tgl`, `sampai_tgl`, `lama_cuti`, `keterangan`, `status_cuti`, `tgl_simpan`) VALUES
	(1, '20230002', 'Umum', '2023-12-25', '2023-12-28', 4, 'Mau merayakan natal', 'Diinput', '2023-12-18');

-- Dumping structure for table kep.tb_dp
CREATE TABLE IF NOT EXISTS `tb_dp` (
  `id_dp` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(20) DEFAULT NULL,
  `dari_jabatan` varchar(50) DEFAULT NULL,
  `ke_jabatan` varchar(50) DEFAULT NULL,
  `alasan` text,
  `status_dp` text,
  `tgl_simpan` date DEFAULT NULL,
  PRIMARY KEY (`id_dp`) USING BTREE,
  KEY `Index 3` (`ke_jabatan`) USING BTREE,
  KEY `Index 2` (`nik`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table kep.tb_dp: ~1 rows (approximately)
INSERT INTO `tb_dp` (`id_dp`, `nik`, `dari_jabatan`, `ke_jabatan`, `alasan`, `status_dp`, `tgl_simpan`) VALUES
	(1, '20230002', 'HRD', 'Staff HRD', 'Jadi mata-mata', 'Demosi', '2023-12-17');

-- Dumping structure for table kep.tb_gaji
CREATE TABLE IF NOT EXISTS `tb_gaji` (
  `id_gaji` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(20) DEFAULT NULL,
  `bln_gaji` varchar(25) DEFAULT NULL,
  `thn_gaji` varchar(4) DEFAULT NULL,
  `gapok` int(11) DEFAULT NULL,
  `uang_makan` int(11) DEFAULT NULL,
  `uang_transport` int(11) DEFAULT NULL,
  `bpjs_kesehatan` int(11) DEFAULT NULL,
  `bpjs_ketenagakerjaan` int(11) DEFAULT NULL,
  `tgl_simpan` date DEFAULT NULL,
  PRIMARY KEY (`id_gaji`),
  KEY `Index 2` (`nik`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table kep.tb_gaji: ~0 rows (approximately)

-- Dumping structure for table kep.tb_karyawan
CREATE TABLE IF NOT EXISTS `tb_karyawan` (
  `nik` varchar(20) NOT NULL,
  `nama` varchar(60) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `alamat` text NOT NULL,
  `email` varchar(60) NOT NULL,
  `status` varchar(60) NOT NULL,
  `tempat_lahir` text NOT NULL,
  `tgl_lahir` date NOT NULL,
  `jenis_kelamin` varchar(15) NOT NULL,
  `agama` varchar(30) NOT NULL,
  `gol_darah` varchar(3) NOT NULL,
  `pendidikan` varchar(50) NOT NULL,
  `jabatan` varchar(50) NOT NULL,
  `foto` text NOT NULL,
  `lam_ijazah` text NOT NULL,
  `lam_kk` text NOT NULL,
  `lam_ktp` text NOT NULL,
  `gaji_pokok` int(11) NOT NULL DEFAULT '0',
  `uang_makan` int(11) NOT NULL DEFAULT '0',
  `uang_transport` int(11) NOT NULL DEFAULT '0',
  `bpjs_kesehatan` int(11) NOT NULL DEFAULT '0',
  `bpjs_ketenagakerjaan` int(11) NOT NULL DEFAULT '0',
  `tgl_masuk` date NOT NULL,
  `tgl_simpan` date NOT NULL,
  `status_kerja` text NOT NULL,
  PRIMARY KEY (`nik`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table kep.tb_karyawan: ~2 rows (approximately)
INSERT INTO `tb_karyawan` (`nik`, `nama`, `no_hp`, `alamat`, `email`, `status`, `tempat_lahir`, `tgl_lahir`, `jenis_kelamin`, `agama`, `gol_darah`, `pendidikan`, `jabatan`, `foto`, `lam_ijazah`, `lam_kk`, `lam_ktp`, `gaji_pokok`, `uang_makan`, `uang_transport`, `bpjs_kesehatan`, `bpjs_ketenagakerjaan`, `tgl_masuk`, `tgl_simpan`, `status_kerja`) VALUES
	('20230001', 'Sri Dewi', '081322360956', 'Palembang Sumsel', 'sridewi@gmail.com', 'Belum Kawin', 'Palembang', '1996-07-16', 'Perempuan', 'Buddha', 'O', 'S1', 'HRD', 'kominfo.jpg', 'kominfo.jpg', 'kominfo.png', 'kominfo.jpg', 5000000, 35000, 50000, 100000, 150000, '2023-08-17', '2023-12-16', 'Aktif'),
	('20230002', 'Siska', '081322360957', 'JL Demang Lebar Daun', 'siskakol@gmail.com', 'Belum Kawin', 'Palembang', '1996-09-17', 'Perempuan', 'Buddha', 'O', 'S1', 'Karyawan', 'Hilook_Brosur.jpg', 'Hilook_Brosur.jpg', 'Hilook_Brosur.jpg', 'Hilook_Brosur.jpg', 4500000, 35000, 45000, 100000, 120000, '2023-09-17', '2023-12-16', 'Aktif');

-- Dumping structure for table kep.tb_pengguna
CREATE TABLE IF NOT EXISTS `tb_pengguna` (
  `id_pengguna` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(20) NOT NULL,
  `password` varchar(150) NOT NULL,
  `akses` varchar(15) NOT NULL,
  `tgl_simpan` date NOT NULL,
  PRIMARY KEY (`id_pengguna`) USING BTREE,
  KEY `nip` (`nik`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table kep.tb_pengguna: ~2 rows (approximately)
INSERT INTO `tb_pengguna` (`id_pengguna`, `nik`, `password`, `akses`, `tgl_simpan`) VALUES
	(1, '20230001', '$2y$10$uh2oF4QHzL5rW9lqyKrVP.FlTbdcWPL0YHyj/SQ6egJy0k9wf8IvG', 'HRD', '2023-12-13'),
	(2, '20230002', '$2y$10$rAOt800Ui4K/Xw4J1Z9ql.I2yEdU./p3hXZMBDyCHEkjei62NjRYG', 'Karyawan', '2023-12-19');

-- Dumping structure for table kep.tb_penugasan
CREATE TABLE IF NOT EXISTS `tb_penugasan` (
  `id_penugasan` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(20) DEFAULT NULL,
  `keterangan` text,
  `dari_tgl` date DEFAULT NULL,
  `sampai_tgl` date DEFAULT NULL,
  `status_penugasan` varchar(50) DEFAULT NULL,
  `tgl_penugasan` date DEFAULT NULL,
  PRIMARY KEY (`id_penugasan`) USING BTREE,
  KEY `Index 2` (`nik`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table kep.tb_penugasan: ~0 rows (approximately)
INSERT INTO `tb_penugasan` (`id_penugasan`, `nik`, `keterangan`, `dari_tgl`, `sampai_tgl`, `status_penugasan`, `tgl_penugasan`) VALUES
	(1, '20230002', 'Ditugaskan ke palembang untuk memantau kinerja karyawan di sana', '2023-12-18', '2023-12-21', 'Diinput', NULL);

-- Dumping structure for table kep.tb_phk
CREATE TABLE IF NOT EXISTS `tb_phk` (
  `id_phk` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(20) DEFAULT NULL,
  `keterangan_phk` text,
  `lampiran` text,
  `status_phk` text,
  `tgl_simpan` date DEFAULT NULL,
  `tgl_phk` date DEFAULT NULL,
  PRIMARY KEY (`id_phk`),
  KEY `Index 2` (`nik`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table kep.tb_phk: ~1 rows (approximately)
INSERT INTO `tb_phk` (`id_phk`, `nik`, `keterangan_phk`, `lampiran`, `status_phk`, `tgl_simpan`, `tgl_phk`) VALUES
	(1, '20230002', 'sudah tidak diperlukan lagi', 'Brosur_Hikvison.jpg', 'Diinput', '2023-12-16', '2023-12-18');

-- Dumping structure for table kep.tb_rekrutment
CREATE TABLE IF NOT EXISTS `tb_rekrutment` (
  `id_rekrutment` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(60) NOT NULL,
  `telp` varchar(15) NOT NULL,
  `alamat` text NOT NULL,
  `email` varchar(60) NOT NULL,
  `status_lamaran` varchar(30) NOT NULL,
  `cv` varchar(255) NOT NULL,
  `tanggal_input` date NOT NULL,
  PRIMARY KEY (`id_rekrutment`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table kep.tb_rekrutment: ~0 rows (approximately)

-- Dumping structure for table kep.tb_resign
CREATE TABLE IF NOT EXISTS `tb_resign` (
  `id_resign` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(20) DEFAULT NULL,
  `alasan_resign` text,
  `lampiran` text,
  `status_resign` varchar(50) DEFAULT NULL,
  `tgl_simpan` date DEFAULT NULL,
  `tgl_resign` date DEFAULT NULL,
  PRIMARY KEY (`id_resign`) USING BTREE,
  KEY `Index 2` (`nik`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table kep.tb_resign: ~1 rows (approximately)
INSERT INTO `tb_resign` (`id_resign`, `nik`, `alasan_resign`, `lampiran`, `status_resign`, `tgl_simpan`, `tgl_resign`) VALUES
	(1, '20230001', 'Sudah Bosan Bekerja', 'DAFTAR_ISI.docx', 'Diinput', '2023-12-17', '2023-12-18');

-- Dumping structure for table kep.tb_rp
CREATE TABLE IF NOT EXISTS `tb_rp` (
  `id_rp` int(11) NOT NULL AUTO_INCREMENT,
  `nik` varchar(20) DEFAULT NULL,
  `keterangan` text,
  `lampiran` text,
  `status_rp` text,
  `tgl_simpan` date DEFAULT NULL,
  PRIMARY KEY (`id_rp`) USING BTREE,
  KEY `Index 2` (`nik`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- Dumping data for table kep.tb_rp: ~1 rows (approximately)
INSERT INTO `tb_rp` (`id_rp`, `nik`, `keterangan`, `lampiran`, `status_rp`, `tgl_simpan`) VALUES
	(1, '20230001', 'Menerima hadiah 1 unit mobil', 'Giyu.jpg', 'REWAD', '2023-12-17');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
